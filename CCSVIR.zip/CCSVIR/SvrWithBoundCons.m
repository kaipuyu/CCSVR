function Fault = SvrWithBoundCons(P, S, W, CS, k, Ev, quantileX)
% SVIRN Support vector interval regression network.
%
[~, Fault.num] = size(quantileX);
% Fault.bias = mean(quantileX, 1);
% Set up the parameters for the Optimisation problem
Q = ones( S.num, 1 );
%Hb = [ k.s2s -k.s2s 2*k.s2swc -2*k.s2swc; -k.s2s k.s2s -2*k.s2swc 2*k.s2swc; zeros(S.num+W.num,2*S.num) k.swc2swc -k.swc2swc; zeros(S.num+W.num,2*S.num) -k.swc2swc k.swc2swc];
Hb = [ k.s2s -k.s2s k.s2swc -k.s2swc; -k.s2s k.s2s -k.s2swc k.s2swc; k.s2swc' -k.s2swc' k.swc2swc -k.swc2swc; -k.s2swc' k.s2swc' -k.swc2swc k.swc2swc];
if W.num ~= 0
    fbl = [Ev.sampleCenterfun - Ev.sampleRadiusfun, Ev.wellCenterfun - Ev.wellRadiusfun, Ev.CSCenterfun - Ev.CSRadiusfun]';
    fup = [Ev.sampleCenterfun + Ev.sampleRadiusfun, Ev.wellCenterfun + Ev.wellRadiusfun, Ev.CSCenterfun + Ev.CSRadiusfun]';
else
    fbl = [Ev.sampleCenterfun - Ev.sampleRadiusfun, Ev.CSCenterfun - Ev.CSRadiusfun]';
    fup = [Ev.sampleCenterfun + Ev.sampleRadiusfun, Ev.CSCenterfun + Ev.CSRadiusfun]';
end

f = [( - quantileX + P.epsl * ones( S.num, Fault.num ) ); ( quantileX + P.epsl * ones( S.num, Fault.num ) ); repmat(-fbl, [1, Fault.num]); repmat(fup, [1, Fault.num])];
vlb = zeros ( 4 * S.num + 2 * W.num + 2 * CS.num_y * CS.num_z, 1 ); % Set the bounds
vub = [ P.C * Q; P.C * Q; inf * ones( 2*(S.num + W.num + CS.num_y * CS.num_z), 1 ) ]; 
Aeq = [ -ones( 1, S.num ), ones( 1, S.num ), -ones( 1, S.num + W.num + CS.num_y * CS.num_z ), ones( 1, S.num + W.num + CS.num_y * CS.num_z ) ];
beq = 0; % Set the constraint Aeqx = beq
x0 = mean( S.output ) * ones( 4 * S.num + 2 * W.num + 2 * CS.num_y * CS.num_z, 1 ); 
% Add small amount of zero order regularisation to
% avoid problems when Hessian is badly conditioned .
% Rank is always less than or equal to S.num.
% Note that adding to much reg will peturb solution
Hb = Hb + 1e-10*eye ( size(Hb) );
% Solve the Optimisation Problem
%fprintf (' Optimising ...\ n');
for i = 1 : Fault.num
    [alpha(:,i), ~, Fault.exitflag(i)] = quadprog(Hb,f(:,i),[],[],Aeq,beq,vlb,vub,x0);
    Fault.beta1(:, i) = alpha( 1: S.num, i ) - alpha( S.num + 1: 2 * S.num, i );
    Fault.beta2(:, i) = alpha( 2 * S.num + 1 : 3 * S.num + W.num + CS.num_y * CS.num_z, i ) - alpha( 3 * S.num + W.num + CS.num_y * CS.num_z + 1: 4 * S.num + 2 * W.num + 2 * CS.num_y * CS.num_z, i );
    epsilon = svtol ( abs ( Fault.beta1(:, i) ));
    svi = find ( abs ( Fault.beta1(:, i) ) >epsilon );
    nsv = length ( svi );
    %fprintf (' Support Vectors: % d (%3.1 f %%)\ n', nsv ,100* nsv /S.num); 
    % find Fault.bias from average of support vectors with interpolation error e
    % SVs with interpolation error e have alphas : 0 < alpha < C
%     alpha1 = alpha( 1 : S.num, : );
%     alpha2 = alpha( S.num + 1 : 2 * S.num, : );
    svii = find ( abs ( Fault.beta1(:, i) ) > epsilon & abs ( Fault.beta1(:, i) ) < ( P.C * Q - epsilon ));
    if ~isempty ( svii )
        Fault.bias(i) = (1/ length ( svii )) * sum ( quantileX( svii, i ) - P.epsl* sign ( Fault.beta1 ( svii, i )) - k.s2s( svii , svi ) * Fault.beta1 ( svi, i ) - k.s2swc( svii , : ) * Fault.beta2(:, i) );
    else
        fprintf ('No support vectors - cannot compute Fault.bias .\n');
    end
    clear epsilon svi nsv svii
end