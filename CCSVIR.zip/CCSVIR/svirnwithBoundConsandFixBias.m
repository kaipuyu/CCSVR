function Ev = svirnwithBoundConsandFixBias(P, S, W, k)
% SVIRN Support vector interval regression network.
Q = ones( S.num, 1 );
Ev.bias1 = mean( 0.5 * ( S.ub_UncertainInterval + S.lb_UncertainInterval ) );
Ev.bias2 = mean( 0.5 * ( S.ub_UncertainInterval - S.lb_UncertainInterval ) );
% Set up the parameters for the Optimisation problem
Hb = [ 2*k.s2s zeros(S.num,S.num) zeros(S.num,S.num+W.num) -2*k.s2sw k.s2sw; zeros(S.num,S.num) 2*k.s2s -2*k.s2sw zeros(S.num,S.num+W.num) k.s2sw; zeros(S.num+W.num,S.num) -2*k.s2sw' 2*k.sw2sw zeros(S.num+W.num,S.num+W.num) -k.sw2sw; -2*k.s2sw' zeros(S.num+W.num,2*S.num+W.num) 2*k.sw2sw -k.sw2sw; k.s2sw' k.s2sw' -k.sw2sw' -k.sw2sw' k.sw2sw];
lb = [ S.lb; W.lb ];
ub = [ S.ub; W.ub ];
if ~isempty(S.delta_wellpick)
    f = [( (Ev.bias1+Ev.bias2)*ones(S.num,1) - S.ub_UncertainInterval' ); ( (-Ev.bias1+Ev.bias2)*ones(S.num,1) + S.lb_UncertainInterval' ); (Ev.bias1-Ev.bias2)*ones(S.num+W.num,1)-lb; (-Ev.bias1-Ev.bias2)*ones(S.num+W.num,1)+ub; (Ev.bias2-1e-7)*ones(S.num+W.num,1)];
else
    f = [( (Ev.bias1+Ev.bias2)*ones(S.num,1) - S.ub_UncertainInterval' ); ( (-Ev.bias1+Ev.bias2)*ones(S.num,1) + S.lb_UncertainInterval' ); (Ev.bias1-Ev.bias2)*ones(S.num+W.num,1)-lb; (-Ev.bias1-Ev.bias2)*ones(S.num+W.num,1)+ub; (Ev.bias2-P.gama)*ones(S.num+W.num,1)];
end
vlb = zeros ( 5 * S.num + 3 * W.num, 1 ); % Set the bounds : alphas >= 0 
vub = [ P.C * Q; P.C * Q; inf * ones( 3*(S.num + W.num), 1 ) ]; 
%Aeq = [ -ones( 1, S.num ) ones( 1, S.num ) -ones( 1, S.num + W.num ) ones( 1, S.num + W.num ); -ones( 1, 2 * S.num ) -ones( 1, 2 * ( S.num + W.num ) ) ];
%beq = [ 0 ; 0 ]; % Set the constraint Aeqx = beq
x0 = Ev.bias1 * ones( 5 * S.num + 3 * W.num ,1 ); 
% Add small amount of zero order regularisation to
% avoid problems when Hessian is badly conditioned .
% Rank is always less than or equal to S.num.
% Note that adding to much reg will peturb solution
Hb = Hb+1e-10* eye ( size (Hb ));
% Solve the Optimisation Problem
%[alpha lambda exitflag] = quadprog(Hb,f,[],[],Aeq,beq,vlb,vub,x0);
[alpha, ~, Ev.exitflag] = quadprog(Hb,f,[],[],[],[],vlb,vub,x0);
%     fprintf (' Status : % s\n', Ev.exitflag );
Ev.beta1 = alpha( 1: S.num ) - alpha( S.num + 1: 2 * S.num );
Ev.beta2 = alpha( 2 * S.num + 1 : 3 * S.num + W.num ) - alpha( 3 * S.num + W.num + 1: 4 * S.num + 2 * W.num );
Ev.beta3 = alpha( 1: S.num ) + alpha( S.num + 1: 2 * S.num );
Ev.beta4 = alpha( 2 * S.num + 1 : 3 * S.num + W.num ) + alpha( 3 * S.num + W.num + 1: 4 * S.num + 2 * W.num );%
Ev.beta5 = alpha( 4 * S.num + 2 * W.num + 1: 5 * S.num + 3 * W.num );