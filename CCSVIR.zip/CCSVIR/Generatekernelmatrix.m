function k = Generatekernelmatrix(P, S, W, U, CS, Jiaoxianinput)
% This function is used to generate the kernel matrix
% S.input is the input of sample point
% S.num is the number of sample points
% W.input is the input of well point
% W.num is the number of well points
% P.ker is the type of the kernel function
% P.segma is the parameter �� of the gaussian kernel function
% P.num_zinter is the number of grid points in the Z direction

k.s2s = svkernel(P.ker, S.input, S.input, P.segma);
% k.s2s is a matrix composed of Gaussian kernel function between the input of each sample point
if W.num ~= 0
    k.s2w = svkernel(P.ker, S.input, W.input, P.segma);
    % k.s2w is a matrix composed of Gaussian kernel function between the input of each sample point and the input of each well path point
    k.w2w = svkernel(P.ker, W.input, W.input, P.segma);
    k.w2u = svkernel(P.ker, W.input, U.input, P.segma);
    % k.w2u is a matrix composed of Gaussian kernel function between the input of each well path point and the input of each point to be interpolated 
    k.w2c = svkernel(P.ker, W.input, CS.input, P.segma);
else
    k.s2w = [];
    k.w2w = [];
    % k.w2w is a matrix composed of Gaussian kernel function between the input of each well path point
    k.w2u = [];
    k.w2c = [];
end
k.s2sw = [k.s2s, k.s2w];
k.w2sw = [k.s2w', k.w2w];
k.sw2sw = [k.s2sw; k.w2sw];
k.s2u = svkernel(P.ker, S.input, U.input, P.segma);
% k.s2u is a matrix composed of Gaussian kernel function between the input of each sample point and the input of each point to be interpolated 
k.sw2u = [k.s2u; k.w2u];
k.s2c = svkernel(P.ker, S.input, CS.input, P.segma);
% k.s2c is a matrix composed of Gaussian kernel function between the input of each sample point and the input of each grid points that used to limit the fault realizations
k.s2swc = [k.s2sw, k.s2c];
k.sw2c = [k.s2c; k.w2c];
k.sw2swc = [k.sw2sw, k.sw2c];
k.c2c = svkernel(P.ker, CS.input, CS.input, P.segma);
k.c2u = svkernel(P.ker, CS.input, U.input, P.segma);
k.swc2u = [k.sw2u; k.c2u];
k.c2swc = [k.sw2c; k.c2c]';
k.swc2swc = [k.sw2swc; k.c2swc];
k.s2j = svkernel( P.ker, S.input, Jiaoxianinput, P.segma );
% k.s2j is a matrix composed of Gaussian kernel function between the input of each sample point and the input of the intersection
if W.num ~= 0
    k.w2j = svkernel( P.ker, W.input, Jiaoxianinput, P.segma );
    % k.w2j is a matrix composed of Gaussian kernel function between the input of each well path point and the input of the intersection
else
    k.w2j = [];
end
k.sw2j = [k.s2j; k.w2j];
k.c2j = svkernel( P.ker, CS.input, Jiaoxianinput, P.segma );
k.swc2j = [k.sw2j; k.c2j];