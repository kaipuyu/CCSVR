function InitialEv = GenerateInitialEnvelop(P, S, W, k, invalidpointyindex, invalidpointzindex)
InitialEv = svirnwithBoundConsandFixBias(P, S, W, k);
InitialEv.Centerfun = InitialEv.beta1' * k.s2u + InitialEv.beta2' * k.sw2u + InitialEv.bias1 * ones(1,P.num_yinter*P.num_zinter);
InitialEv.Radiusfun = InitialEv.beta3' * k.s2u - InitialEv.beta4' * k.sw2u + InitialEv.beta5' * k.sw2u + InitialEv.bias2 * ones(1,P.num_yinter*P.num_zinter);
InitialEv.Fault = reshape(InitialEv.Centerfun,P.num_yinter,P.num_zinter)';
InitialEv.upenvelope = reshape(InitialEv.Centerfun+InitialEv.Radiusfun,P.num_yinter,P.num_zinter)';
InitialEv.blenvelope = reshape(InitialEv.Centerfun-InitialEv.Radiusfun,P.num_yinter,P.num_zinter)';
for i=1:length(invalidpointzindex)
    InitialEv.upenvelope(invalidpointzindex(i), invalidpointyindex(i)) = inf;
    InitialEv.blenvelope(invalidpointzindex(i), invalidpointyindex(i)) = inf;
    InitialEv.Fault(invalidpointzindex(i), invalidpointyindex(i)) = inf;
end
InitialEv.sampleCenterfun = InitialEv.beta1' * k.s2s + InitialEv.beta2' * k.s2sw' + InitialEv.bias1 * ones(1,S.num);
InitialEv.sampleRadiusfun = InitialEv.beta3' * k.s2s - InitialEv.beta4' * k.s2sw' + InitialEv.beta5' * k.s2sw' + InitialEv.bias2 * ones(1,S.num);
InitialEv.jiaoxianCenterfun = InitialEv.beta1' * k.s2j + InitialEv.beta2' * k.sw2j + InitialEv.bias1 * ones(1,P.num_yinter);
InitialEv.jiaoxianRadiusfun = InitialEv.beta3' * k.s2j - InitialEv.beta4' * k.sw2j + InitialEv.beta5' * k.sw2j + InitialEv.bias2 * ones(1,P.num_yinter);