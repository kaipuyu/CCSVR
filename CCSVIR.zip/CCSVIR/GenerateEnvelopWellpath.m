function Evwellpath = GenerateEnvelopWellpath(P, S, W, k, invalidpointyindex, invalidpointzindex)
Evwellpath = svirnwithBoundConsandFixBias(P, S, W, k);
Evwellpath.Centerfun = Evwellpath.beta1' * k.s2u + Evwellpath.beta2' * k.sw2u + Evwellpath.bias1 * ones(1,P.num_yinter*P.num_zinter);
Evwellpath.Radiusfun = Evwellpath.beta3' * k.s2u - Evwellpath.beta4' * k.sw2u + Evwellpath.beta5' * k.sw2u + Evwellpath.bias2 * ones(1,P.num_yinter*P.num_zinter);
Evwellpath.Fault = reshape(Evwellpath.Centerfun,P.num_yinter,P.num_zinter)';
Evwellpath.upenvelope = reshape(Evwellpath.Centerfun+Evwellpath.Radiusfun,P.num_yinter,P.num_zinter)';
Evwellpath.blenvelope = reshape(Evwellpath.Centerfun-Evwellpath.Radiusfun,P.num_yinter,P.num_zinter)';
for i=1:length(invalidpointzindex)
    Evwellpath.upenvelope(invalidpointzindex(i), invalidpointyindex(i)) = inf;
    Evwellpath.blenvelope(invalidpointzindex(i), invalidpointyindex(i)) = inf;
    Evwellpath.Fault(invalidpointzindex(i), invalidpointyindex(i)) = inf;
end
Evwellpath.sampleCenterfun = Evwellpath.beta1' * k.s2s + Evwellpath.beta2' * k.s2sw' + Evwellpath.bias1 * ones(1,S.num);
Evwellpath.sampleRadiusfun = Evwellpath.beta3' * k.s2s - Evwellpath.beta4' * k.s2sw' + Evwellpath.beta5' * k.s2sw' + Evwellpath.bias2 * ones(1,S.num);
Evwellpath.jiaoxianCenterfun = Evwellpath.beta1' * k.s2j + Evwellpath.beta2' * k.sw2j + Evwellpath.bias1 * ones(1,P.num_yinter);
Evwellpath.jiaoxianRadiusfun = Evwellpath.beta3' * k.s2j - Evwellpath.beta4' * k.sw2j + Evwellpath.beta5' * k.sw2j + Evwellpath.bias2 * ones(1,P.num_yinter);