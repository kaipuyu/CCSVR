%% 
clear all;
close all;
load faultdata.txt
faultseedpoint = faultdata;

P.beta=0.999;                          % The parameter �� for converting an opportunity constraint to the deterministic interval constraint(Formula 4)
P.gama = 5.5;                          % The Parameter �� in equation 16
P.flag = 1;                            % Indicate the output of training samples follows normal distribution
P.ker = 'rbf';                         % Kernel type
P.C = 200;                             % Super parameter C in objective function
P.segma = 1200;                        % The parameter �� of the gaussian kernel function
P.num_yinter = 200;                    % The fault plane is projected onto the YOZ plane, and the smallest rectangle containing the projection area is divided by regular grid. P.num_yinter is the number of grid points in the Y direction
P.num_zinter = 100;                    % P.num_zinter is the number of grid points in the Z direction
P.epsl = 30;                           % The width �� of the insensitive tube

S.Y = faultseedpoint(:, 3);                        % The Y-coordinate of the sample points
S.Z = faultseedpoint(:, 4);                        % The Z-coordinate of the sample points
S.input = [S.Y S.Z];                               % Input of sample point composed of Y-coordinate and Z-coordinate of sample point
S.output = faultseedpoint(:, 2);                   % The output sampling value of sample point
S.num = length(S.output);                          % The number of sample points
S.lb = S.output - 230 * ones(length(S.output),1);  % The lower bound of sample points
S.ub = S.output + 230 * ones(length(S.output),1);  % The upper bound of sample points
S.delta = 85*ones(1, length(S.output));            % The parameter �� of the uncertainty interval
S.confid = 0.8*ones(1, length(S.output));          % The predetermined confidence
S.wellpickindex = [90;357];                        % The 89th and 355th sample points are well pick points
S.delta_wellpick = [];                             % Well pick points are not used to generate the initial envelope
S.givenquantile = ones(S.num,1)*[0.02, 0.15, 0.5, 0.85, 0.98];    % Quantiles of the distribution of sample point output (used to generate different fault realizations)

U.interY = repmat(linspace(min(S.Y), max(S.Y), P.num_yinter), [P.num_zinter 1]);
U.interZ = repmat(linspace(min(S.Z), max(S.Z), P.num_zinter)', [1 P.num_yinter]);
U.Y = reshape(U.interY', 1, P.num_yinter * P.num_zinter)';  % Y-coordinate of the point to be interpolated
U.Z = reshape(U.interZ', 1, P.num_yinter * P.num_zinter)';  % Z-coordinate of the point to be interpolated
U.input = [U.Y, U.Z];  

W.index = [];                                    % index of well path points
W.input = U.input(W.index,:);                    % input of well path points
W.num = length(W.input);                         % The number of well path points
W.lb = [];                                       % lbi in equation (12) for well path points
W.ub = [];                                       % ubi in equation (11) for well path points

CS.num_y = 80;                                     
CS.num_z = 50;           
CS.interY = repmat(linspace(min(S.Y), max(S.Y), CS.num_y), [CS.num_z 1]);
CS.interZ = repmat(linspace(min(S.Z), max(S.Z), CS.num_z)', [1 CS.num_y]);
CS.Y = reshape(CS.interY', 1, CS.num_y * CS.num_z)';  % Y-coordinate of grid points that used to limit the fault realizations
CS.Z = reshape(CS.interZ', 1, CS.num_y * CS.num_z)';  % Z-coordinate of grid points that used to limit the fault realizations
CS.input = [CS.Y, CS.Z];                              % Input of grid points that used to limit the fault realizations

Yminv = min(S.Y);                                
Ymaxv = max(S.Y);                                
Jiaoxianinput(:,1) = linspace(Yminv, Ymaxv, P.num_yinter)';
% Y-coordinate of the intersection of the envelope and plane z = S.Z(S.wellpickindex(1))
Jiaoxianinput(:,2) = S.Z(S.wellpickindex(1)) * ones( P.num_yinter, 1 );
% Z-coordinate of the intersection of the envelope and plane z = S.Z(S.wellpickindex(1))
k = Generatekernelmatrix(P, S, W, U, CS, Jiaoxianinput);
% Generate kernel matrix
FindUncettainInterval;
% The chance constraint (Eq. 3) is transformed into a deterministic interval constraint (Eq. 4), and obtain two endpoints of the interval constraint
[invalidpointyindex,invalidpointzindex] = Findinvalidinterpointindex(S, P, faultseedpoint);
% Find the points outside the interpolation region
%%
InitialEv = GenerateInitialEnvelop(P, S, W, k, invalidpointyindex, invalidpointzindex);
% Generate the initial envelopes
Initial_flag = 1;   % Flag of whether the generated envelopes are the initial envelopes                                                                            % �����ĵ�ǰ�������Ƿ��ǳ�ʼ�����ߵı�־
PlotEnvelope(P, S, W, U, InitialEv, InitialEv, Jiaoxianinput, Initial_flag);
% Draw the initial envelopes and its section
%%
W.index = [9352 9361 9369 9377];                                % index of well path points
W.input = U.input(W.index,:);                                   % input of well path points
W.num = length(W.input);                                        % The number of well path points
W.lb = [658000;658000;658000;658000];                           % lbi in equation (12) for well path points
W.ub = [659290.3144; 659198.6785; 659139.3373; 659017.2014];    % ubi in equation (11) for well path points
k.s2w = svkernel(P.ker, S.input, W.input, P.segma);
% A matrix composed of Gaussian kernel function between the input of each sample point and the input of each well path point
k.s2sw = [k.s2s, k.s2w];
% k.s2s is a matrix composed of Gaussian kernel function between the input of each sample point
k.w2w = svkernel(P.ker, W.input, W.input, P.segma);
% A matrix composed of Gaussian kernel function between the input of each well path point
k.w2sw = [k.s2w', k.w2w];
k.sw2sw = [k.s2sw; k.w2sw];
k.w2u = svkernel(P.ker, W.input, U.input, P.segma);
% A matrix composed of Gaussian kernel function between the input of each well path point and the input of each point to be interpolated 
k.w2c = svkernel(P.ker, W.input, CS.input, P.segma);
% A matrix composed of Gaussian kernel function between the input of each well path point and the input of each grid points that used to limit the fault realizations
k.s2swc = [k.s2sw, k.s2c];
k.sw2u = [k.s2u; k.w2u];
k.sw2c = [k.s2c; k.w2c];
k.sw2swc = [k.sw2sw, k.sw2c];
k.swc2u = [k.sw2u; k.c2u];
k.c2swc = [k.sw2c; k.c2c]';
k.swc2swc = [k.sw2swc; k.c2swc];
k.w2j = svkernel( P.ker, W.input, Jiaoxianinput, P.segma );
% A matrix composed of Gaussian kernel function between the input of each
% well path point and the input of the intersection
k.sw2j = [k.s2j; k.w2j];
k.swc2j = [k.sw2j; k.c2j];
Evwellpath = GenerateEnvelopWellpath(P, S, W, k, invalidpointyindex, invalidpointzindex);
% Generate the updated envelopes after adding the well path points
Initial_flag = 0;                                    
% Flag of whether the generated envelopes are the initial envelopes
PlotEnvelope(P, S, W, U, Evwellpath, InitialEv, Jiaoxianinput, Initial_flag);
% Draw the fault envelopes generated from 799 fault points and well path points, and the section of envelopes
%%
S.delta_wellpick = [4.5; 4.5];                     % The confidence radius �� of well pick points
S.confid_wellpick = [0.98; 0.98];                  % The predetermined confidence of well pick points
S.delta(S.wellpickindex) = S.delta_wellpick;
S.confid(S.wellpickindex) = S.confid_wellpick;
FindUncettainInterval;                             
% The chance constraint (Eq. 3) is transformed into a deterministic interval constraint (Eq. 4), and obtain two endpoints of the interval constraint after adding well pick points
S.lb( S.wellpickindex ) = S.lb_UncertainInterval( S.wellpickindex );
S.ub( S.wellpickindex ) = S.ub_UncertainInterval( S.wellpickindex );
Evwellpathwellpick = GenerateEnvelopWellpathWellpick(P, S, W, CS, k, invalidpointyindex, invalidpointzindex);
% Generate the updated envelopes after adding the well path points and well pick points
Initial_flag = 0;   % Flag of whether the generated envelopes are the initial envelopes   
PlotEnvelope(P, S, W, U, Evwellpathwellpick, InitialEv, Jiaoxianinput, Initial_flag);
% Draw the fault envelopes generated from 799 fault points, well path points and well pick points, and the section of envelopes
%%
Fault = GenerateFaultRealizationByQuantile(P, S, W, CS, k, Evwellpathwellpick);
%Generate fault realization by quantile
PlotFault(P, S, W, U, Fault, Evwellpathwellpick, InitialEv, Jiaoxianinput, Initial_flag);
% Draw the multiple fault realizations generated by formula (25) with the envelopes as the boundary constraints