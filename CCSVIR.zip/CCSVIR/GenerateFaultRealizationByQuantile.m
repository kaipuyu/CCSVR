function Fault = GenerateFaultRealizationByQuantile(P, S, W, CS, k, Ev)
[quantileX] = Findquantile(P, S);
Fault = SvrWithBoundCons(P, S, W, CS, k, Ev, quantileX);
for i =1 :Fault.num
    Fault.Realizationfun(i,:) = Fault.beta1(:,i)' * k.s2u + Fault.beta2(:,i)' * k.swc2u + Fault.bias(i) * ones(1, P.num_yinter*P.num_zinter);
    Fault.jiaoxian(i,:) = Fault.beta1(:,i)' * k.s2j + Fault.beta2(:,i)' * k.swc2j + Fault.bias(i) * ones(1, P.num_yinter);
    Fault.Realization(:, :, i) = reshape(Fault.Realizationfun(i, :), P.num_yinter, P.num_zinter)';
end