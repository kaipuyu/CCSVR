% function [S.lb_UncertainInterval, S.ub_UncertainInterval, S.std] = FindUncettainInterval(S, P)
% This function is used to transforme the chance constraint (Eq. 3) into a deterministic interval constraint (Eq. 4), and obtain two endpoints of the interval constrain
% S.output is the output sampling value of sample point
% S.delta is the parameter �� of the uncertainty interval
% S.confid is the predetermined confidence
% P.beta is the parameter �� for converting an opportunity constraint to the deterministic interval constraint(Formula 4)
% If P.flag == 1, the training sample output follows a normal distribution, and S.std is the standard deviation
% If P.flag == 2, the training sample output follows a uniform distribution, and S.std is the interval radius (b-a) / 2 
% If P.flag == 3, the training sample output follows a symmetrical triangle distribution, and S.std is the interval radius (b-a) / 2

if P.flag==1
    S.std = S.delta ./ norminv( (ones( 1, S.num ) + S.confid) / 2 );
    S.lb_UncertainInterval = S.std .* norminv( (ones( 1, S.num ) - P.beta) / 2 ) + S.output';
    S.ub_UncertainInterval = 2 * S.output' - S.lb_UncertainInterval;
end
if P.flag==2
    S.std = S.delta ./ S.confid;
    S.lb_UncertainInterval = S.output' - S.std;
    S.ub_UncertainInterval = 2 * S.output' - S.lb_UncertainInterval;
end
if P.flag==3
    S.std = S.delta ./ ( ones( 1, S.num ) - sqrt( ones( 1, S.num ) - S.confid ) );
    S.lb_UncertainInterval = S.output' - S.std;
    S.ub_UncertainInterval = 2 * S.output' - S.lb_UncertainInterval;
end