function [invalidpointyindex,invalidpointzindex] = Findinvalidinterpointindex(S, P, faultseedpoint)
% This function is used to find the points outside the interpolation region
% S.Y is the Y-coordinate of the sample points
% S.Z is the Z-coordinate of the sample points
% The fault is projected onto the YOZ plane, and the smallest rectangle containing the projection area is divided by regular grid. P.num_yinter is the number of grid points in the Y direction
% P.num_zinter is the number of grid points in the Z direction
strikeindex = faultseedpoint(:,1);   % strikeindex is the index of fault strike
sticknum = max( strikeindex );
Yminv = min( S.Y );    
Ymaxv = max( S.Y );    
Zminv = min( S.Z );    
Zmaxv = max( S.Z );    
firststrikeindex = find( strikeindex == 1 );
laststrikeindex = find( strikeindex == sticknum );
yfirststrike = S.Y( firststrikeindex );
zfirststrike = S.Z( firststrikeindex );
ylaststrike = S.Y( laststrikeindex );
zlaststrike = S.Z( laststrikeindex );
ylaststrike(length(ylaststrike)+1) = Ymaxv;
zlaststrike(length(ylaststrike)) = Zminv;
yinterval = ( Ymaxv - Yminv ) / ( P.num_yinter - 1 );
zinterval = ( Zmaxv - Zminv ) / ( P.num_zinter - 1 );
zleft = Zminv: zinterval: Zmaxv;
zright = Zminv: zinterval: Zmaxv;
yleft = interp1(zfirststrike, yfirststrike, zright, 'PCHIP');
yright = interp1(zlaststrike, ylaststrike,  zleft, 'PCHIP');
interpointnum = 0;
for i=1: floor( ( max(yleft)-Yminv ) / yinterval ) + 1
    for j=1: P.num_zinter
        currentpointy = Yminv + ( i - 1 ) * yinterval;
        if  currentpointy < yleft( j )
            interpointnum = interpointnum + 1;
            invalidpointyindex( interpointnum ) = i;
            invalidpointzindex( interpointnum ) = j;
        end
    end
end
for i=floor( ( min(yright) - Yminv ) / yinterval ) + 2 : floor( ( Ymaxv - Yminv ) / yinterval ) + 1
    for j=1: P.num_zinter
        currentpointy = Yminv + ( i - 1 ) * yinterval;
        if  currentpointy > yright( j )
            interpointnum = interpointnum + 1;
            invalidpointyindex( interpointnum ) = i;
            invalidpointzindex( interpointnum ) = j;
        end
    end
end