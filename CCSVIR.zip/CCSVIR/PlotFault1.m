function PlotFault1(P, S, W, U, Fault, Ev, InitialEv, Jiaoxianinput, Initial_flag)
% draw the fault realization
% close all
figure
% subfigure1 = subplot( 2, 3, 1 );
% set( subfigure1, 'Position', [0.0637, 0.475, 0.1496, 0.652]);
cdata = cat( 3, 0.9333*ones(P.num_zinter, P.num_yinter), 0.77255*ones(P.num_zinter, P.num_yinter), 0.5686*ones(P.num_zinter, P.num_yinter) );
F1 = surf(Fault.Realization(:, :, 1), U.interY, U.interZ, cdata);
shading interp
hold on
if Initial_flag == 1 
    cdata=cat( 3, 0.51765*ones(P.num_zinter, P.num_yinter), 0.4392*ones(P.num_zinter, P.num_yinter), 1*ones(P.num_zinter, P.num_yinter) );
    up = surf(Ev.upenvelope, U.interY, U.interZ, cdata);
    hold on
    cdata=cat( 3, 0.51765*ones(P.num_zinter, P.num_yinter), 0.4392*ones(P.num_zinter, P.num_yinter), 1*ones(P.num_zinter, P.num_yinter) );
    bl = surf(Ev.blenvelope, U.interY, U.interZ, cdata);
else
    cdata=cat( 3, 0*ones(P.num_zinter, P.num_yinter), 0.8078*ones(P.num_zinter, P.num_yinter), 0.8196*ones(P.num_zinter, P.num_yinter) );
    up = surf(Ev.upenvelope, U.interY, U.interZ, cdata);
    hold on
    for i=1
        [wellpathx,wellpathy,wellpathz]=sphere(200);
        wellpathx = wellpathx*20 + W.ub(i) + 10;
        wellpathy = wellpathy*30 + W.input(i,1);
        wellpathz = wellpathz*30 + W.input(i,2);
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        surf(wellpathx, wellpathy, wellpathz, cdata);
    end
    hold on
    if ~isempty(S.delta_wellpick)
        for i=1
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.output(S.wellpickindex(i));
            wellpicky = wellpicky*30 + S.Y(S.wellpickindex(i));
            wellpickz = wellpickz*30 + S.Z(S.wellpickindex(1));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            surf(wellpickx, wellpicky, wellpickz, cdata);
            hold on
        end
    end
    cdata = cat( 3, 0*ones(P.num_zinter, P.num_yinter), 0.8078*ones(P.num_zinter, P.num_yinter), 0.8196*ones(P.num_zinter, P.num_yinter) );%����ʯɫ
    bl = surf(Ev.blenvelope, U.interY, U.interZ, cdata);
    hold on
    for i = 2:W.num
        [wellpathx,wellpathy,wellpathz] = sphere(200);
        wellpathx = wellpathx*20 + W.ub(i)+10;
        wellpathy = wellpathy*30 + W.input(i,1);
        wellpathz = wellpathz*30 + W.input(i,2);
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        surf(wellpathx, wellpathy, wellpathz, cdata);
        hold on
    end
    if ~isempty(S.delta_wellpick)
        for i=2:length(S.wellpickindex)
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.output(S.wellpickindex(i));
            wellpicky = wellpicky*30 + S.Y(S.wellpickindex(i));
            wellpickz = wellpickz*30 + S.Z(S.wellpickindex(1));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            surf(wellpickx, wellpicky, wellpickz, cdata);
        end
    end
end
shading interp
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(F1,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
xlim([658000 660600]);
ylim([3298000 3311000]);
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(a)');
SaveFigure('C:\Users\ysc\Desktop\paper imgs', 'FaultRealizationbyCCSVR_a')

% subfigure2 = subplot( 2, 3, 2 );
% set( subfigure2, 'Position', [0.34, 0.475, 0.1496, 0.652]);
figure
cdata = cat( 3, 0.9333*ones(P.num_zinter, P.num_yinter), 0.77255*ones(P.num_zinter, P.num_yinter), 0.5686*ones(P.num_zinter, P.num_yinter) );
F2 = surf(Fault.Realization(:, :, 2), U.interY, U.interZ, cdata);
shading interp
hold on
if Initial_flag == 1 % Flag of whether the generated envelopes are the initial envelopes
    cdata=cat( 3, 0.51765*ones(P.num_zinter, P.num_yinter), 0.4392*ones(P.num_zinter, P.num_yinter), 1*ones(P.num_zinter, P.num_yinter) );
    up = surf(Ev.upenvelope, U.interY, U.interZ, cdata);
    hold on
    cdata=cat( 3, 0.51765*ones(P.num_zinter, P.num_yinter), 0.4392*ones(P.num_zinter, P.num_yinter), 1*ones(P.num_zinter, P.num_yinter) );
    bl = surf(Ev.blenvelope, U.interY, U.interZ, cdata);
else
    cdata=cat( 3, 0*ones(P.num_zinter, P.num_yinter), 0.8078*ones(P.num_zinter, P.num_yinter), 0.8196*ones(P.num_zinter, P.num_yinter) );
    up = surf(Ev.upenvelope, U.interY, U.interZ, cdata);
    hold on
    for i=1
        [wellpathx,wellpathy,wellpathz]=sphere(200);
        wellpathx = wellpathx*20 + W.ub(i) + 10;
        wellpathy = wellpathy*30 + W.input(i,1);
        wellpathz = wellpathz*30 + W.input(i,2);
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        surf(wellpathx, wellpathy, wellpathz, cdata);
    end
    hold on
    if ~isempty(S.delta_wellpick)
        for i=1
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.output(S.wellpickindex(i));
            wellpicky = wellpicky*30 + S.Y(S.wellpickindex(i));
            wellpickz = wellpickz*30 + S.Z(S.wellpickindex(1));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            surf(wellpickx, wellpicky, wellpickz, cdata);
            hold on
        end
    end
    cdata = cat( 3, 0*ones(P.num_zinter, P.num_yinter), 0.8078*ones(P.num_zinter, P.num_yinter), 0.8196*ones(P.num_zinter, P.num_yinter) );%����ʯɫ
    bl = surf(Ev.blenvelope, U.interY, U.interZ, cdata);
    hold on
    for i = 2:W.num
        [wellpathx,wellpathy,wellpathz] = sphere(200);
        wellpathx = wellpathx*20 + W.ub(i)+10;
        wellpathy = wellpathy*30 + W.input(i,1);
        wellpathz = wellpathz*30 + W.input(i,2);
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        surf(wellpathx, wellpathy, wellpathz, cdata);
        hold on
    end
    if ~isempty(S.delta_wellpick)
        for i=2:length(S.wellpickindex)
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.output(S.wellpickindex(i));
            wellpicky = wellpicky*30 + S.Y(S.wellpickindex(i));
            wellpickz = wellpickz*30 + S.Z(S.wellpickindex(1));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            surf(wellpickx, wellpicky, wellpickz, cdata);
        end
    end
end
shading interp
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(F2,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
xlim([658000 660600]);
ylim([3298000 3311000]);
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(b)');
SaveFigure('C:\Users\ysc\Desktop\paper imgs', 'FaultRealizationbyCCSVR_b')

% subfigure3 = subplot( 2, 3, 3 );
% set( subfigure3, 'Position', [0.6163, 0.475, 0.1496, 0.652]);
figure
cdata = cat( 3, 0.9333*ones(P.num_zinter, P.num_yinter), 0.77255*ones(P.num_zinter, P.num_yinter), 0.5686*ones(P.num_zinter, P.num_yinter) );
F3 = surf(Fault.Realization(:, :, 3), U.interY, U.interZ, cdata);
shading interp
hold on
if Initial_flag == 1 % Flag of whether the generated envelopes are the initial envelopes
    cdata=cat( 3, 0.51765*ones(P.num_zinter, P.num_yinter), 0.4392*ones(P.num_zinter, P.num_yinter), 1*ones(P.num_zinter, P.num_yinter) );
    up = surf(Ev.upenvelope, U.interY, U.interZ, cdata);
    hold on
    cdata=cat( 3, 0.51765*ones(P.num_zinter, P.num_yinter), 0.4392*ones(P.num_zinter, P.num_yinter), 1*ones(P.num_zinter, P.num_yinter) );
    bl = surf(Ev.blenvelope, U.interY, U.interZ, cdata);
else
    cdata=cat( 3, 0*ones(P.num_zinter, P.num_yinter), 0.8078*ones(P.num_zinter, P.num_yinter), 0.8196*ones(P.num_zinter, P.num_yinter) );
    up = surf(Ev.upenvelope, U.interY, U.interZ, cdata);
    hold on
    for i=1
        [wellpathx,wellpathy,wellpathz]=sphere(200);
        wellpathx = wellpathx*20 + W.ub(i) + 10;
        wellpathy = wellpathy*30 + W.input(i,1);
        wellpathz = wellpathz*30 + W.input(i,2);
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        surf(wellpathx, wellpathy, wellpathz, cdata);
    end
    hold on
    if ~isempty(S.delta_wellpick)
        for i=1
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.output(S.wellpickindex(i));
            wellpicky = wellpicky*30 + S.Y(S.wellpickindex(i));
            wellpickz = wellpickz*30 + S.Z(S.wellpickindex(1));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            surf(wellpickx, wellpicky, wellpickz, cdata);
            hold on
        end
    end
    cdata = cat( 3, 0*ones(P.num_zinter, P.num_yinter), 0.8078*ones(P.num_zinter, P.num_yinter), 0.8196*ones(P.num_zinter, P.num_yinter) );%����ʯɫ
    bl = surf(Ev.blenvelope, U.interY, U.interZ, cdata);
    hold on
    for i = 2:W.num
        [wellpathx,wellpathy,wellpathz] = sphere(200);
        wellpathx = wellpathx*20 + W.ub(i)+10;
        wellpathy = wellpathy*30 + W.input(i,1);
        wellpathz = wellpathz*30 + W.input(i,2);
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        surf(wellpathx, wellpathy, wellpathz, cdata);
        hold on
    end
    if ~isempty(S.delta_wellpick)
        for i=2:length(S.wellpickindex)
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.output(S.wellpickindex(i));
            wellpicky = wellpicky*30 + S.Y(S.wellpickindex(i));
            wellpickz = wellpickz*30 + S.Z(S.wellpickindex(1));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            surf(wellpickx, wellpicky, wellpickz, cdata);
        end
    end
end
shading interp
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(F3,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
xlim([658000 660600]);
ylim([3298000 3311000]);
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(c)');
SaveFigure('C:\Users\ysc\Desktop\paper imgs', 'FaultRealizationbyCCSVR_c')

% subfigure4 = subplot( 2, 3, 4 );
% set( subfigure4, 'Position', [0.0637, 0.02, 0.1496, 0.652]);
figure
cdata = cat( 3, 0.9333*ones(P.num_zinter, P.num_yinter), 0.77255*ones(P.num_zinter, P.num_yinter), 0.5686*ones(P.num_zinter, P.num_yinter) );
F4 = surf(Fault.Realization(:, :, 4), U.interY, U.interZ, cdata);
shading interp
hold on
if Initial_flag == 1 % Flag of whether the generated envelopes are the initial envelopes
    cdata=cat( 3, 0.51765*ones(P.num_zinter, P.num_yinter), 0.4392*ones(P.num_zinter, P.num_yinter), 1*ones(P.num_zinter, P.num_yinter) );
    up = surf(Ev.upenvelope, U.interY, U.interZ, cdata);
    hold on
    cdata=cat( 3, 0.51765*ones(P.num_zinter, P.num_yinter), 0.4392*ones(P.num_zinter, P.num_yinter), 1*ones(P.num_zinter, P.num_yinter) );
    bl = surf(Ev.blenvelope, U.interY, U.interZ, cdata);
else
    cdata=cat( 3, 0*ones(P.num_zinter, P.num_yinter), 0.8078*ones(P.num_zinter, P.num_yinter), 0.8196*ones(P.num_zinter, P.num_yinter) );
    up = surf(Ev.upenvelope, U.interY, U.interZ, cdata);
    hold on
    for i=1
        [wellpathx,wellpathy,wellpathz]=sphere(200);
        wellpathx = wellpathx*20 + W.ub(i) + 10;
        wellpathy = wellpathy*30 + W.input(i,1);
        wellpathz = wellpathz*30 + W.input(i,2);
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        surf(wellpathx, wellpathy, wellpathz, cdata);
    end
    hold on
    if ~isempty(S.delta_wellpick)
        for i=1
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.output(S.wellpickindex(i));
            wellpicky = wellpicky*30 + S.Y(S.wellpickindex(i));
            wellpickz = wellpickz*30 + S.Z(S.wellpickindex(1));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            surf(wellpickx, wellpicky, wellpickz, cdata);
            hold on
        end
    end
    cdata = cat( 3, 0*ones(P.num_zinter, P.num_yinter), 0.8078*ones(P.num_zinter, P.num_yinter), 0.8196*ones(P.num_zinter, P.num_yinter) );%����ʯɫ
    bl = surf(Ev.blenvelope, U.interY, U.interZ, cdata);
    hold on
    for i = 2:W.num
        [wellpathx,wellpathy,wellpathz] = sphere(200);
        wellpathx = wellpathx*20 + W.ub(i)+10;
        wellpathy = wellpathy*30 + W.input(i,1);
        wellpathz = wellpathz*30 + W.input(i,2);
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        surf(wellpathx, wellpathy, wellpathz, cdata);
        hold on
    end
    if ~isempty(S.delta_wellpick)
        for i=2:length(S.wellpickindex)
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.output(S.wellpickindex(i));
            wellpicky = wellpicky*30 + S.Y(S.wellpickindex(i));
            wellpickz = wellpickz*30 + S.Z(S.wellpickindex(1));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            surf(wellpickx, wellpicky, wellpickz, cdata);
        end
    end
end
shading interp
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(F4,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
xlim([658000 660600]);
ylim([3298000 3311000]);
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(d)');
SaveFigure('C:\Users\ysc\Desktop\paper imgs', 'FaultRealizationbyCCSVR_d')

% subfigure5 = subplot( 2, 3, 5 );
% set( subfigure5, 'Position', [0.34, 0.02, 0.1496, 0.652]);
figure
cdata = cat( 3, 0.9333*ones(P.num_zinter, P.num_yinter), 0.77255*ones(P.num_zinter, P.num_yinter), 0.5686*ones(P.num_zinter, P.num_yinter) );
F5 = surf(Fault.Realization(:, :, 5), U.interY, U.interZ, cdata);
shading interp
hold on
if Initial_flag == 1 % �����ĵ�ǰ�������Ƿ��ǳ�ʼ�����ߵı�־
    cdata=cat( 3, 0.51765*ones(P.num_zinter, P.num_yinter), 0.4392*ones(P.num_zinter, P.num_yinter), 1*ones(P.num_zinter, P.num_yinter) );
    up = surf(Ev.upenvelope, U.interY, U.interZ, cdata);
    hold on
    cdata=cat( 3, 0.51765*ones(P.num_zinter, P.num_yinter), 0.4392*ones(P.num_zinter, P.num_yinter), 1*ones(P.num_zinter, P.num_yinter) );
    bl = surf(Ev.blenvelope, U.interY, U.interZ, cdata);
else
    cdata=cat( 3, 0*ones(P.num_zinter, P.num_yinter), 0.8078*ones(P.num_zinter, P.num_yinter), 0.8196*ones(P.num_zinter, P.num_yinter) );
    up = surf(Ev.upenvelope, U.interY, U.interZ, cdata);
    hold on
    for i=1
        [wellpathx,wellpathy,wellpathz]=sphere(200);
        wellpathx = wellpathx*20 + W.ub(i) + 10;
        wellpathy = wellpathy*30 + W.input(i,1);
        wellpathz = wellpathz*30 + W.input(i,2);
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        surf(wellpathx, wellpathy, wellpathz, cdata);
    end
    hold on
    if ~isempty(S.delta_wellpick)
        for i=1
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.output(S.wellpickindex(i));
            wellpicky = wellpicky*30 + S.Y(S.wellpickindex(i));
            wellpickz = wellpickz*30 + S.Z(S.wellpickindex(1));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            surf(wellpickx, wellpicky, wellpickz, cdata);
            hold on
        end
    end
    cdata = cat( 3, 0*ones(P.num_zinter, P.num_yinter), 0.8078*ones(P.num_zinter, P.num_yinter), 0.8196*ones(P.num_zinter, P.num_yinter) );%����ʯɫ
    bl = surf(Ev.blenvelope, U.interY, U.interZ, cdata);
    hold on
    for i = 2:W.num
        [wellpathx,wellpathy,wellpathz] = sphere(200);
        wellpathx = wellpathx*20 + W.ub(i)+10;
        wellpathy = wellpathy*30 + W.input(i,1);
        wellpathz = wellpathz*30 + W.input(i,2);
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        surf(wellpathx, wellpathy, wellpathz, cdata);
        hold on
    end
    if ~isempty(S.delta_wellpick)
        for i=2:length(S.wellpickindex)
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.output(S.wellpickindex(i));
            wellpicky = wellpicky*30 + S.Y(S.wellpickindex(i));
            wellpickz = wellpickz*30 + S.Z(S.wellpickindex(1));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            surf(wellpickx, wellpicky, wellpickz, cdata);
        end
    end
end
shading interp
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(F5,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
xlim([658000 660600]);
ylim([3298000 3311000]);
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(e)');
SaveFigure('C:\Users\ysc\Desktop\paper imgs', 'FaultRealizationbyCCSVR_e')

% subfigure6 = subplot( 2, 3, 6 );
% set( subfigure6, 'Position', [0.6138, 0.0619, 0.117, 0.552]);
figure
if Initial_flag == 1 % �����ĵ�ǰ�������Ƿ��ǳ�ʼ�����ߵı�־
    for i = 1 : Fault.num
        plot( Fault.jiaoxian(i,:)', Jiaoxianinput( :, 1 ), 'Color', [0.9333 0.77255 0.5686], 'linewidth', 1.5);
        hold on
    end
    plot( Ev.jiaoxianCenterfun + Ev.jiaoxianRadiusfun, Jiaoxianinput( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
    hold on
    plot( Ev.jiaoxianCenterfun - Ev.jiaoxianRadiusfun, Jiaoxianinput( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
else
    for i = 1 : Fault.num
        plot( Fault.jiaoxian(i,:)', Jiaoxianinput( :, 1 ), 'Color', [0.9333 0.77255 0.5686], 'linewidth', 1.5);
        hold on
    end
    plot( InitialEv.jiaoxianCenterfun + InitialEv.jiaoxianRadiusfun, Jiaoxianinput( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
    hold on
    plot( Ev.jiaoxianCenterfun + Ev.jiaoxianRadiusfun, Jiaoxianinput( :, 1 ), 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);
    hold on
    plot( W.ub, W.input(:,1), 'ro','MarkerSize',4,'markerfacecolor','r' )
    hold on
    plot( InitialEv.jiaoxianCenterfun - InitialEv.jiaoxianRadiusfun, Jiaoxianinput( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
    hold on
    plot( Ev.jiaoxianCenterfun - Ev.jiaoxianRadiusfun, Jiaoxianinput( :, 1 ), 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);
    hold on
    if ~isempty(S.delta_wellpick)
        plot( S.output(S.wellpickindex), S.input(S.wellpickindex,1), 'ko','MarkerSize',4,'markerfacecolor','k' )
    end
    hold on
end
set(gca,'linewidth',1.5);
set(gca,'xtick',[6.58*10^5,6.585*10^5,6.59*10^5,6.595*10^5,6.6*10^5,6.605*10^5],'ytick',[3.298*10^6,3.302*10^6,3.306*10^6,3.31*10^6]);
axis([min(Ev.jiaoxianCenterfun - Ev.jiaoxianRadiusfun)-50,max(Ev.jiaoxianCenterfun + Ev.jiaoxianRadiusfun)+50, min(Jiaoxianinput( :, 1 ))-200, max(Jiaoxianinput( :, 1 ))+200]);
set(gca,'DataAspectRatio',[1 3.5 2])
xlabel('(f)');
set(gcf,'outerposition',get(0,'screensize'));
SaveFigure('C:\Users\ysc\Desktop\paper imgs', 'FaultRealizationbyCCSVR_f')