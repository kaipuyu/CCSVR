%%
% generate the initial envelope
clear all;
close all;
load faultdata.txt
C = 200;    % parameter in objective function
ker = 'rbf';
segema = 1200;   % parameter of kernel function
faultseedpoint = faultdata;
yinternum = 460;  % number of grids in the y direction
zinternum = 230;  % number of grids in the z direction
strikeindex = faultseedpoint(:,1);  % index of fault stick
x = faultseedpoint(:,2);  % x-coordinate of sample point
y = faultseedpoint(:,3);  % y-coordinate of sample point
z = faultseedpoint(:,4);  % z-coordinate of sample point
yminv = min(y);   % minimum value of y coordinate of the region to be interpolated
ymaxv = max(y);   % maximum value of y coordinate of the region to be interpolated
zminv = min(z);   % minimum value of z coordinate of the region to be interpolated
zmaxv = max(z);   % maximum value of z coordinate of the region to be interpolated
intery = repmat(linspace(yminv, ymaxv, yinternum), [zinternum 1]);
interz = repmat(linspace(zminv, zmaxv, zinternum)', [1 yinternum]);
unX = [reshape(intery',1,yinternum*zinternum)' reshape(interz',1,yinternum*zinternum)'];  % input of points to be interpolated
sampleX = [y z];    % input of sample point
sampleY = x;        % output of sample point
Q = ones(length(sampleY),1);
delta = 85*ones(1,length(sampleY));   % parameter related to the opportunity constraint, which is the parameter in equation (10)
confid = 0.8*ones(1,length(sampleY)); % confidence in equation (10)
beta = 0.999;   % probability value that is very close to 1
wellpickindex = [];    % index of well pick points
delta_wellpick = [];   % parameter related to the opportunity constraint of well pick points
confid_wellpick = [];  % confidence of well pick points
wellpathindex = [];    % index of well path points
wellpathX = unX(wellpathindex,:);   % input of well path points
wellpathlb = [];  % lbi in equation (19) for well path points
wellpathub = [];  % ubi in equation (18) for well path points
flag = 1; %The mark of distribution type that the output of training sample obeys
[Y2, Y1, ~] = FindUncettainInterval(delta, confid, beta, wellpickindex, delta_wellpick, confid_wellpick, sampleY, flag);
% find the two endpoints of the uncertainty interval converted from the confidence constraint of the training sample output
Y2 = Y2';
Y1 = Y1';
samplelb = sampleY-230*ones(length(sampleY),1);   % lbi in equation (19) for training sample points
sampleub = sampleY+230*ones(length(sampleY),1);   % ubi in equation (18) for training sample points
samplelb( wellpickindex ) = Y2( wellpickindex );
sampleub( wellpickindex ) = Y1( wellpickindex );
k1 = svkernel( ker, sampleX, unX, segema );
%k2 = svkernel( ker, [ sampleX; wellpathX ], unX, segema ); 
k2 = [k1 ; svkernel( ker, wellpathX, unX, segema )];
k3 = svkernel( ker, sampleX, sampleX, segema );
%k4 = svkernel( ker, [ sampleX; wellpathX ], sampleX, segema );
k4 = [k3 ; svkernel( ker, wellpathX, sampleX, segema )];
[beta1, beta2, beta3, beta4, beta5, bias1, bias2] = svirnwithBoundConsandFixBias(sampleX, wellpathX, Y1, Y2, samplelb, sampleub, wellpathlb, wellpathub, k3, ker, C, Q, segema);
fprintf (' Interpolating ....\ n')
Centerfun = beta1' * k1 + beta2' * k2 + bias1 * ones(1,yinternum*zinternum);
Radiusfun = beta3' * k1 - beta4' * k2 + beta5' * k2 + bias2 * ones(1,yinternum*zinternum);
interx = reshape(Centerfun,size(intery,2),size(intery,1))';
upenvelope = reshape(Centerfun+Radiusfun,size(intery,2),size(intery,1))';
blenvelope = reshape(Centerfun-Radiusfun,size(intery,2),size(intery,1))';
[invalidpointyindex,invalidpointzindex] = findinvalidinterpointindex(y, z, strikeindex, yinternum, zinternum);
for i=1:length(invalidpointzindex)
    upenvelope(invalidpointzindex(i),invalidpointyindex(i))=inf;
    blenvelope(invalidpointzindex(i),invalidpointyindex(i))=inf;
    interx(invalidpointzindex(i),invalidpointyindex(i))=inf;
end
sampleCenterfun = beta1' * k3 + beta2' * k4 + bias1 * ones(1,length(sampleX));
sampleRadiusfun = beta3' * k3 - beta4' * k4 + beta5' * k4 + bias2 * ones(1,length(sampleX));
samplelb = (sampleCenterfun - sampleRadiusfun)';
sampleub = (sampleCenterfun + sampleRadiusfun)';
jiaoxianX(:,1) = linspace(yminv, ymaxv, yinternum)';
jiaoxiannum = length(jiaoxianX(:,1));
jiaoxianX(:,2) = z(89) * ones( jiaoxiannum, 1 );
k5 = svkernel( ker, sampleX, jiaoxianX, segema );
k6 = [k5 ; svkernel( ker, wellpathX, jiaoxianX, segema )];
jiaoxianCenterfun = beta1' * k5 + beta2' * k6 + bias1 * ones(1,jiaoxiannum);
jiaoxianRadiusfun = beta3' * k5 - beta4' * k6 + beta5' * k6 + bias2 * ones(1,jiaoxiannum);
Initialupperenvelope = (jiaoxianCenterfun + jiaoxianRadiusfun)' + 15 * ones(size(jiaoxianCenterfun))';
Initiallowerenvelope = (jiaoxianCenterfun - jiaoxianRadiusfun)' - 15 * ones(size(jiaoxianCenterfun))';
save('InitialEnvelopeandSampleBound','Initialupperenvelope','Initiallowerenvelope','samplelb','sampleub','k1','k3');
save('InitialEnvelopeforplot','interx','intery','interz','upenvelope','blenvelope','jiaoxianCenterfun','jiaoxianRadiusfun','jiaoxianX','Initialupperenvelope','Initiallowerenvelope','samplelb','sampleub');

%%
% Draw the initial envelope
clear all
close all
load InitialEnvelopeforplot
subfigure1 = subplot( 1, 3, 1 );
set( subfigure1, 'Position', [0.1, 0.11, 0.1870, 0.8150]);
cdata=cat( 3, 1*ones(size(interx)), 0.498*ones(size(interx)), 0*ones(size(interx)) );
mid=surf(interx,intery,interz,cdata);
shading interp
hold on
cdata=cat( 3, 0.51765*ones(size(interx)), 0.4392*ones(size(interx)),1*ones(size(interx)) );
up=surf(upenvelope, intery, interz,cdata);
shading interp
hold on
cdata=cat( 3, 0.51765*ones(size(interx)), 0.4392*ones(size(interx)),1*ones(size(interx)) );
bl=surf(blenvelope, intery, interz,cdata);
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(mid,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
hold on
xlim([658000 660600]);
ylim([3298000 3311000]);
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite')  
xlabel('(a)');
subfigure2 = subplot( 1, 3, 2 );
set( subfigure2, 'Position', [0.35, 0.11, 0.1870, 0.8150]);
cdata=cat( 3, 1*ones(size(interx)), 0.498*ones(size(interx)), 0*ones(size(interx)) );
mid=surf(interx,intery,interz,cdata);
shading interp
hold on
cdata=cat( 3, 0.51765*ones(size(interx)), 0.4392*ones(size(interx)),1*ones(size(interx)) );
up=surf(upenvelope, intery, interz,cdata);
shading interp
hold on
cdata=cat( 3, 0.51765*ones(size(interx)), 0.4392*ones(size(interx)),1*ones(size(interx)) );%��ɫ
bl=surf(blenvelope, intery, interz,cdata);
set(up,'FaceAlpha',1);
set(bl,'FaceAlpha',1);
set(mid,'FaceAlpha',0.3);
set(gca,'DataAspectRatio',[1.4 2 2])
xlim([658000 660600]);
ylim([3298000 3311000]);
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(b)');
subfigure3 = subplot( 1, 3, 3 );
set( subfigure3, 'Position', [0.6, 0.168, 0.146, 0.69]);
plot( jiaoxianCenterfun, jiaoxianX( :, 1 ), 'Color', [1 0.498 0], 'linewidth', 1.5);
hold on
plot( Initialupperenvelope, jiaoxianX( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
hold on
hold on
plot( Initiallowerenvelope, jiaoxianX( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
set(gca,'linewidth',1.5);
set(gca,'xtick',[6.58*10^5,6.585*10^5,6.59*10^5,6.595*10^5,6.6*10^5,6.605*10^5],'ytick',[3.298*10^6,3.302*10^6,3.306*10^6,3.31*10^6]);
axis([min(jiaoxianCenterfun - jiaoxianRadiusfun)-50,max(jiaoxianCenterfun + jiaoxianRadiusfun)+50,min(jiaoxianX( :, 1 ))-200, max(jiaoxianX( :, 1 ))+200]);
set(gca,'DataAspectRatio',[1 3.5 2])
xlabel('(c)');


%%
%use the well path points and fault points to generate envelopes
clear all;
close all;
load InitialEnvelopeandSampleBound
load faultdata.txt
C = 200;
ker = 'rbf';
segema = 1200;
faultseedpoint = faultdata;
yinternum = 460;
zinternum = 230;
strikeindex = faultseedpoint(:,1);
x = faultseedpoint(:,2);
y = faultseedpoint(:,3);
z = faultseedpoint(:,4);
yminv = min(y);
ymaxv = max(y);
zminv = min(z);
zmaxv = max(z);
intery = repmat(linspace(yminv, ymaxv, yinternum), [zinternum 1]);
interz = repmat(linspace(zminv, zmaxv, zinternum)', [1 yinternum]);
unX = [reshape(intery',1,yinternum*zinternum)' reshape(interz',1,yinternum*zinternum)'];
sampleX = [y z];
sampleY = x ;
Q = ones(length(sampleY),1);
delta = 85*ones(1,length(sampleY));
confid = 0.8*ones(1,length(sampleY));
beta = 0.999;
wellpickindex = [];
delta_wellpick = [];
confid_wellpick = [];
wellpathindex = [48648 48670 48688 48706];  % index of well path points
wellpathX = unX(wellpathindex,:);  % input of well path points
flag = 1;
[Y2, Y1, ~] = FindUncettainInterval(delta, confid, beta, wellpickindex, delta_wellpick, confid_wellpick, sampleY, flag);
Y2 = Y2';
Y1 = Y1';
samplelb = sampleY-230*ones(length(sampleY),1);
sampleub = sampleY+230*ones(length(sampleY),1);
samplelb( wellpickindex ) = Y2( wellpickindex );
sampleub( wellpickindex ) = Y1( wellpickindex );
wellpathlb = [658000;658000;658000;658000];    % lbi in equation (19) for well path points
wellpathub = [659290.3144; 659198.6785; 659139.3373; 659017.2014];    % ubi in equation (18) for well path points
[beta1, beta2, beta3, beta4, beta5, bias1, bias2] = svirnwithBoundConsandFixBias(sampleX, wellpathX, Y1, Y2, samplelb, sampleub, wellpathlb, wellpathub, k3, ker, C, Q, segema);
fprintf (' Interpolating ....\ n')
%k1 = svkernel( ker, sampleX, unX, segema );
k2 = [k1 ; svkernel( ker, wellpathX, unX, segema )]; 
Centerfun = beta1' * k1 + beta2' * k2 + bias1 * ones(1,yinternum*zinternum);
Radiusfun = beta3' * k1 - beta4' * k2 + beta5' * k2 + bias2 * ones(1,yinternum*zinternum);
interx = reshape(Centerfun,size(intery,2),size(intery,1))';
upenvelope = reshape(Centerfun+Radiusfun,size(intery,2),size(intery,1))';
blenvelope = reshape(Centerfun-Radiusfun,size(intery,2),size(intery,1))';
[invalidpointyindex,invalidpointzindex] = findinvalidinterpointindex(y, z, strikeindex, yinternum, zinternum);
for i=1:length(invalidpointzindex)
    upenvelope(invalidpointzindex(i),invalidpointyindex(i))=inf;
    blenvelope(invalidpointzindex(i),invalidpointyindex(i))=inf;
    interx(invalidpointzindex(i),invalidpointyindex(i))=inf;
end
jiaoxianX(:,1) = linspace(yminv, ymaxv, yinternum)';
jiaoxiannum = length(jiaoxianX(:,1));
jiaoxianX(:,2) = z(89) * ones( jiaoxiannum, 1 );
k5 = svkernel( ker, sampleX, jiaoxianX, segema );
k6 = [k5 ; svkernel( ker, wellpathX, jiaoxianX, segema )];
jiaoxianCenterfun = beta1' * k5 + beta2' * k6 + bias1 * ones(1,jiaoxiannum);
jiaoxianRadiusfun = beta3' * k5 - beta4' * k6 + beta5' * k6 + bias2 * ones(1,jiaoxiannum);

%%
%draw the envelope generated by the well path points and fault points
subfigure1 = subplot( 1, 3, 1 );
set( subfigure1, 'Position', [0.1, 0.11, 0.1870, 0.8150]);
set( subfigure1, 'Position', [0.0791666666666662 0.11 0.1870 0.8150]);
cdata=cat( 3, 1*ones(size(interx)), 0.498*ones(size(interx)), 0*ones(size(interx)) );
mid=surf(interx,intery,interz,cdata);
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
up=surf(upenvelope, intery, interz,cdata);
for i=1
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);%���ư뾶Ϊ2����
end
% legendposition=legend( 'a fault realization','The envelopes adjusted by wellpath','wellpath', 4 );
% set(legendposition,'Position', [0.265885418102456 0.767597367340878 0.125520830461756 0.0568260553390386])
hold on
for i=2:length(wellpathindex)
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
bl=surf(blenvelope, intery, interz,cdata);
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(mid,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
hold on
xlim([658000 660600]);
ylim([3298000 3311000]);
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(a)');
subfigure2 = subplot( 1, 3, 2 );
set( subfigure2, 'Position', [0.35, 0.11, 0.1870, 0.8150]);
cdata=cat( 3, 1*ones(size(interx)), 0.498*ones(size(interx)), 0*ones(size(interx)) );
mid=surf(interx,intery,interz,cdata);
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
up=surf(upenvelope, intery, interz,cdata);
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
bl=surf(blenvelope, intery, interz,cdata);
set(up,'FaceAlpha',1);
set(bl,'FaceAlpha',1);
set(mid,'FaceAlpha',0.3);
set(gca,'DataAspectRatio',[1.4 2 2])
xlim([658000 660600]);
ylim([3298000 3311000]);
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite')  
xlabel('(b)');
subfigure3 = subplot( 1, 3, 3 );
set( subfigure3, 'Position', [0.62083333333333, 0.168, 0.146, 0.69]);
plot( jiaoxianCenterfun, jiaoxianX( :, 1 ), 'Color', [1 0.498 0], 'linewidth', 1.5);
hold on
plot( jiaoxianCenterfun + jiaoxianRadiusfun, jiaoxianX( :, 1 ), 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);
hold on
plot( Initialupperenvelope, jiaoxianX( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
hold on
plot([659290.3144; 659198.6785; 659139.3373; 659017.2014], unX(wellpathindex,1), 'ro','MarkerSize',4,'markerfacecolor','r' )
hold on
plot( sampleY(wellpickindex), sampleX(wellpickindex,1), 'ko','MarkerSize',4,'markerfacecolor','k' )
% legendposition=legend( 'a fault realization','The envelopes adjusted by wellpath','the initial envelopes','wellpath', 1 );
% set(legendposition,'Position', [0.632239584769122 0.759816355807701 0.125520830461755 0.0741510721683832])
hold on
plot( jiaoxianCenterfun - jiaoxianRadiusfun, jiaoxianX( :, 1 ), 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);
hold on
plot( Initiallowerenvelope, jiaoxianX( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
set(gca,'linewidth',1.5);
set(gca,'xtick',[6.58*10^5,6.585*10^5,6.59*10^5,6.595*10^5,6.6*10^5,6.605*10^5],'ytick',[3.298*10^6,3.302*10^6,3.306*10^6,3.31*10^6]);
axis([min(jiaoxianCenterfun - jiaoxianRadiusfun)-50,max(jiaoxianCenterfun + jiaoxianRadiusfun)+50,min(jiaoxianX( :, 1 ))-200, max(jiaoxianX( :, 1 ))+200]);
set(gca,'DataAspectRatio',[1 3.5 2])
xlabel('(c)');

%%
%use the well path points, well pick points and fault points to generate envelopes
clear all;
close all;
load InitialEnvelopeandSampleBound
load faultdata.txt
epsl = 30;
C = 200;
ker = 'rbf';
segema = 1200;
faultseedpoint = faultdata;
yinternum = 460;
zinternum = 230;
strikeindex = faultseedpoint(:,1);
x = faultseedpoint(:,2);
y = faultseedpoint(:,3);
z = faultseedpoint(:,4);
yminv = min(y);
ymaxv = max(y);
zminv = min(z);
zmaxv = max(z);
intery = repmat(linspace(yminv, ymaxv, yinternum), [zinternum 1]);
interz = repmat(linspace(zminv, zmaxv, zinternum)', [1 yinternum]);
unX = [reshape(intery',1,yinternum*zinternum)' reshape(interz',1,yinternum*zinternum)'];%����ֵ�������
sampleX = [y z];
sampleY = x;
Q = ones(length(sampleY),1);
delta = 85*ones(1,length(sampleY));
confid = 0.8*ones(1,length(sampleY));
beta = 0.999;
wellpickindex = [89;355];
delta_wellpick = [4.5;4.5];
confid_wellpick = [0.98;0.98];
gama = 5.5;
wellpathindex = [48648 48670 48688 48706];
wellpathX = unX(wellpathindex,:);
flag = 1;
[Y2, Y1, biaozhuncha] = FindUncettainInterval(delta, confid, beta, wellpickindex, delta_wellpick, confid_wellpick, sampleY, flag);
Y2 = Y2';
Y1 = Y1';
samplelb = sampleY-230*ones(length(sampleY),1);
sampleub = sampleY+230*ones(length(sampleY),1);
samplelb( wellpickindex ) = Y2( wellpickindex );
sampleub( wellpickindex ) = Y1( wellpickindex );
wellpathlb = [658000;658000;658000;658000];
wellpathub = [659290.3144; 659198.6785; 659139.3373; 659017.2014];
[beta1, beta2, beta3, beta4, beta5, bias1, bias2] = svirnwithBoundConsandFixBias1(sampleX, wellpathX, Y1, Y2, samplelb, sampleub, wellpathlb, wellpathub, gama, k3, ker, C, Q, segema);
fprintf (' Interpolating ....\ n')
k2 = [k1 ; svkernel( ker, wellpathX, unX, segema )]; 
Centerfun = beta1' * k1 + beta2' * k2 + bias1 * ones(1,yinternum*zinternum);
Radiusfun = beta3' * k1 - beta4' * k2 + beta5' * k2 + bias2 * ones(1,yinternum*zinternum);
interx = reshape(Centerfun,size(intery,2),size(intery,1))';
upenvelope = reshape(Centerfun+Radiusfun,size(intery,2),size(intery,1))';
blenvelope = reshape(Centerfun-Radiusfun,size(intery,2),size(intery,1))';
[invalidpointyindex,invalidpointzindex] = findinvalidinterpointindex(y, z, strikeindex, yinternum, zinternum);
for i=1:length(invalidpointzindex)
    upenvelope(invalidpointzindex(i),invalidpointyindex(i))=inf;
    blenvelope(invalidpointzindex(i),invalidpointyindex(i))=inf;
    interx(invalidpointzindex(i),invalidpointyindex(i))=inf;
end
k4 = [k3 ; svkernel( ker, wellpathX, sampleX, segema )];
sampleCenterfun = beta1' * k3 + beta2' * k4 + bias1 * ones(1,length(sampleX));
sampleRadiusfun = beta3' * k3 - beta4' * k4 + beta5' * k4 + bias2 * ones(1,length(sampleX));
jiaoxianX(:,1) = linspace(yminv, ymaxv, yinternum)';
jiaoxiannum = length(jiaoxianX(:,1));
jiaoxianX(:,2) = z(89) * ones( jiaoxiannum, 1 );
%jiaoxianX(:,2) = z(wellpickindex) * ones( jiaoxiannum, 1 );
k5 = svkernel( ker, sampleX, jiaoxianX, segema );
k6 = [k5 ; svkernel( ker, wellpathX, jiaoxianX, segema )];
jiaoxianCenterfun = beta1' * k5 + beta2' * k6 + bias1 * ones(1,jiaoxiannum);
jiaoxianRadiusfun = beta3' * k5 - beta4' * k6 + beta5' * k6 + bias2 * ones(1,jiaoxiannum);

%%
%draw the envelope generated by the well path points, well pick points and fault points
subfigure1 = subplot( 1, 3, 1 );
set( subfigure1, 'Position', [0.1, 0.11, 0.1870, 0.8150]);
cdata=cat( 3, 1*ones(size(interx)), 0.498*ones(size(interx)), 0*ones(size(interx)) );
mid=surf(interx,intery,interz,cdata);
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
up=surf(upenvelope, intery, interz,cdata);
hold on
for i=1
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
hold on
for i=1
    [wellpickx,wellpicky,wellpickz]=sphere(200);
    wellpickx = wellpickx*20+sampleY(wellpickindex(i));
    wellpicky = wellpicky*30+sampleX(wellpickindex(i),1);
    wellpickz = wellpickz*30+z(89);
    cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
    surf(wellpickx, wellpicky, wellpickz, cdata);
end
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );%����ʯɫ
bl=surf(blenvelope, intery, interz,cdata);
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(mid,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
hold on
for i=2:length(wellpathindex)
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
hold on
for i=2:length(wellpickindex)
    [wellpickx,wellpicky,wellpickz]=sphere(200);
    wellpickx = wellpickx*20+sampleY(wellpickindex(i));
    wellpicky = wellpicky*30+sampleX(wellpickindex(i),1);
    wellpickz = wellpickz*30+z(89);
    cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
    surf(wellpickx, wellpicky, wellpickz, cdata);
end
xlim([658000 660600]);
ylim([3298000 3311000]);
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
 xlabel('(a)');

subfigure2 = subplot( 1, 3, 2 );
set( subfigure2, 'Position', [0.35, 0.11, 0.1870, 0.8150]);
cdata=cat( 3, 1*ones(size(interx)), 0.498*ones(size(interx)), 0*ones(size(interx)) );
mid=surf(interx,intery,interz,cdata);
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
up=surf(upenvelope, intery, interz,cdata);
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );%����ʯɫ
bl=surf(blenvelope, intery, interz,cdata);
set(up,'FaceAlpha',1);
set(bl,'FaceAlpha',1);
set(mid,'FaceAlpha',0.3);
set(gca,'DataAspectRatio',[1.4 2 2])
xlim([658000 660600]);
ylim([3298000 3311000]);
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(b)');

subfigure3 = subplot( 1, 3, 3 );
set( subfigure3, 'Position', [0.6, 0.168, 0.146, 0.69]);
load InitialEnvelopeandSampleBound
plot( jiaoxianCenterfun, jiaoxianX( :, 1 ), 'Color', [1 0.498 0], 'linewidth', 1.5);
hold on
plot( jiaoxianCenterfun + jiaoxianRadiusfun, jiaoxianX( :, 1 ), 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);
hold on
plot( Initialupperenvelope, jiaoxianX( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
hold on
plot([659290.3144; 659198.6785; 659139.3373; 659017.2014], unX(wellpathindex,1), 'ro','MarkerSize',4,'markerfacecolor','r' )
hold on
plot( sampleY(wellpickindex), sampleX(wellpickindex,1), 'ko','MarkerSize',4,'markerfacecolor','k' )
hold on
plot( jiaoxianCenterfun - jiaoxianRadiusfun, jiaoxianX( :, 1 ), 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);
hold on
plot( Initiallowerenvelope, jiaoxianX( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
hold on
plot([659290.3144; 659198.6785; 659139.3373; 659017.2014], unX(wellpathindex,1), 'ro','MarkerSize',4,'markerfacecolor','r' )
hold on
plot( sampleY(wellpickindex), sampleX(wellpickindex,1), 'ko','MarkerSize',4,'markerfacecolor','k' )
set(gca,'linewidth',1.5);
set(gca,'xtick',[6.58*10^5,6.585*10^5,6.59*10^5,6.595*10^5,6.6*10^5,6.605*10^5],'ytick',[3.298*10^6,3.302*10^6,3.306*10^6,3.31*10^6]);
axis([min(jiaoxianCenterfun - jiaoxianRadiusfun)-50,max(jiaoxianCenterfun + jiaoxianRadiusfun)+50,min(jiaoxianX( :, 1 ))-200, max(jiaoxianX( :, 1 ))+200]);
set(gca,'DataAspectRatio',[1 3.5 2])
xlabel('(c)');

%%
%creat fault realization by quantile
extrapointindex = [47454 48374 47913 47915 48070 48990 48531 48529 49448 46535 37656 38576 39037 39497 39957 40417 40711 40877 41171 41337 41632 41796 42091 42257 96600 97060 97520 97980 98440 98900 99360 99820 100279 100280 100739	100740 101199 101200 101659 101660 102119 102120 102579 102580 103039 103040 103498 103499 103500 103958	103959	103960	104418	104419	104420	104878	104879	104880	105338	105339	105340	105798	105799	105800];
givenquantile = ones(length(sampleY),1)*[0.02, 0.15, 0.5, 0.85, 0.98];
for i = 1 : size( givenquantile, 2 )
    [FaultRealizationfun(i, :), jiaoxianFault(i, :)]=CreatFaultRealizationByQuantile(C, ker, segema, k1, k5, Q, epsl, y, z, yinternum, sampleX, sampleY, unX, [wellpathindex extrapointindex], Y2, Y1, flag, givenquantile(:,i), biaozhuncha', Centerfun, Radiusfun, sampleCenterfun, sampleRadiusfun);
end
for i = 1 : size( givenquantile, 2 )
    FaultRealization(:, :, i) = reshape(FaultRealizationfun(i, :),size(intery,2),size(intery,1))';
    for j=1:length(invalidpointzindex)
        FaultRealization(invalidpointzindex(j),invalidpointyindex(j),i)=inf;
    end
end

%%
% draw the fault realization
subfigure1 = subplot( 2, 3, 1 );
set( subfigure1, 'Position', [0.0637, 0.475, 0.1496, 0.652]);
cdata=cat( 3, 0.9333*ones(size(interx)), 0.77255*ones(size(interx)), 0.5686*ones(size(interx)) );
Fault1 = surf(FaultRealization(:, :, 1), intery, interz,cdata);
hold on
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
up=surf(upenvelope, intery, interz,cdata);
hold on
for i=1
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
hold on
for i=1
    [wellpickx,wellpicky,wellpickz]=sphere(200);
    wellpickx = wellpickx*20+sampleY(wellpickindex(i));
    wellpicky = wellpicky*30+sampleX(wellpickindex(i),1);
    wellpickz = wellpickz*30+z(89);
    cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
    surf(wellpickx, wellpicky, wellpickz, cdata);
end
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
bl=surf(blenvelope, intery, interz,cdata);
hold on
for i=2:length(wellpathindex)
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
hold on
for i=2:length(wellpickindex)
    [wellpickx,wellpicky,wellpickz]=sphere(200);
    wellpickx = wellpickx*20+sampleY(wellpickindex(i));
    wellpicky = wellpicky*30+sampleX(wellpickindex(i),1);
    wellpickz = wellpickz*30+z(89);
    cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );%����ɫ
    surf(wellpickx, wellpicky, wellpickz, cdata);
end
xlim([658000 660600]);
ylim([3298000 3311000]);
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(Fault1,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(a)');
subfigure2 = subplot( 2, 3, 2 );
set( subfigure2, 'Position', [0.34, 0.475, 0.1496, 0.652]);
cdata=cat( 3, 0.9333*ones(size(interx)), 0.77255*ones(size(interx)), 0.5686*ones(size(interx)) );
Fault2 = surf(FaultRealization(:, :, 2), intery, interz,cdata);
hold on
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
up=surf(upenvelope, intery, interz,cdata);
hold on
for i=1
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
hold on
for i=1
    [wellpickx,wellpicky,wellpickz]=sphere(200);
    wellpickx = wellpickx*20+sampleY(wellpickindex(i));
    wellpicky = wellpicky*30+sampleX(wellpickindex(i),1);
    wellpickz = wellpickz*30+z(89);
    cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
    surf(wellpickx, wellpicky, wellpickz, cdata);
end
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
bl=surf(blenvelope, intery, interz,cdata);
hold on
for i=2:length(wellpathindex)
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
hold on
for i=2:length(wellpickindex)
    [wellpickx,wellpicky,wellpickz]=sphere(200);
    wellpickx = wellpickx*20+sampleY(wellpickindex(i));
    wellpicky = wellpicky*30+sampleX(wellpickindex(i),1);
    wellpickz = wellpickz*30+z(89);
    cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
    surf(wellpickx, wellpicky, wellpickz, cdata);
end
xlim([658000 660600]);
ylim([3298000 3311000]);
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(Fault2,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(b)');
subfigure3 = subplot( 2, 3, 3 );
set( subfigure3, 'Position', [0.6163, 0.475, 0.1496, 0.652]);
cdata=cat( 3, 0.9333*ones(size(interx)), 0.77255*ones(size(interx)), 0.5686*ones(size(interx)) );
Fault3 = surf(FaultRealization(:, :, 3), intery, interz,cdata);
hold on
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
up=surf(upenvelope, intery, interz,cdata);
hold on
for i=1
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
hold on
for i=1
    [wellpickx,wellpicky,wellpickz]=sphere(200);
    wellpickx = wellpickx*20+sampleY(wellpickindex(i));
    wellpicky = wellpicky*30+sampleX(wellpickindex(i),1);
    wellpickz = wellpickz*30+z(89);
    cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
    surf(wellpickx, wellpicky, wellpickz, cdata);
end
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
bl=surf(blenvelope, intery, interz,cdata);
hold on
for i=2:length(wellpathindex)
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
hold on
for i=2:length(wellpickindex)
    [wellpickx,wellpicky,wellpickz]=sphere(200);
    wellpickx = wellpickx*20+sampleY(wellpickindex(i));
    wellpicky = wellpicky*30+sampleX(wellpickindex(i),1);
    wellpickz = wellpickz*30+z(89);
    cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
    surf(wellpickx, wellpicky, wellpickz, cdata);
end
xlim([658000 660600]);
ylim([3298000 3311000]);
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(Fault3,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(c)');
subfigure4 = subplot( 2, 3, 4 );
set( subfigure4, 'Position', [0.0637, 0.02, 0.1496, 0.652]);
cdata=cat( 3, 0.9333*ones(size(interx)), 0.77255*ones(size(interx)), 0.5686*ones(size(interx)) );
Fault4 = surf(FaultRealization(:, :, 4), intery, interz,cdata);
hold on
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
up=surf(upenvelope, intery, interz,cdata);
hold on
for i=1
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
hold on
for i=1
    [wellpickx,wellpicky,wellpickz]=sphere(200);
    wellpickx = wellpickx*20+sampleY(wellpickindex(i));
    wellpicky = wellpicky*30+sampleX(wellpickindex(i),1);
    wellpickz = wellpickz*30+z(89);
    cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
    surf(wellpickx, wellpicky, wellpickz, cdata);
end
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
bl=surf(blenvelope, intery, interz,cdata);
hold on
for i=2:length(wellpathindex)
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
hold on
for i=2:length(wellpickindex)
    [wellpickx,wellpicky,wellpickz]=sphere(200);
    wellpickx = wellpickx*20+sampleY(wellpickindex(i));
    wellpicky = wellpicky*30+sampleX(wellpickindex(i),1);
    wellpickz = wellpickz*30+z(89);
    cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
    surf(wellpickx, wellpicky, wellpickz, cdata);
end
xlim([658000 660600]);
ylim([3298000 3311000]);
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(Fault4,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(d)');
subfigure5 = subplot( 2, 3, 5 );
set( subfigure5, 'Position', [0.34, 0.02, 0.1496, 0.652]);
cdata=cat( 3, 0.9333*ones(size(interx)), 0.77255*ones(size(interx)), 0.5686*ones(size(interx)) );
Fault5 = surf(FaultRealization(:, :, 5), intery, interz,cdata);
hold on
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
up=surf(upenvelope, intery, interz,cdata);
hold on
for i=1
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
hold on
for i=1
    [wellpickx,wellpicky,wellpickz]=sphere(200);
    wellpickx = wellpickx*20+sampleY(wellpickindex(i));
    wellpicky = wellpicky*30+sampleX(wellpickindex(i),1);
    wellpickz = wellpickz*30+z(89);
    cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
    surf(wellpickx, wellpicky, wellpickz, cdata);
end
shading interp
hold on
cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );
bl=surf(blenvelope, intery, interz,cdata);
hold on
for i=2:length(wellpathindex)
    [wellpathx,wellpathy,wellpathz]=sphere(200);
    wellpathx = wellpathx*20+wellpathub(i)+10;
    wellpathy = wellpathy*30+wellpathX(i,1);
    wellpathz = wellpathz*30+wellpathX(i,2);
    cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
    surf(wellpathx, wellpathy, wellpathz, cdata);
end
hold on
for i=2:length(wellpickindex)
    [wellpickx,wellpicky,wellpickz]=sphere(200);
    wellpickx = wellpickx*20+sampleY(wellpickindex(i));
    wellpicky = wellpicky*30+sampleX(wellpickindex(i),1);
    wellpickz = wellpickz*30+z(89);
    cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
    surf(wellpickx, wellpicky, wellpickz, cdata);
end
xlim([658000 660600]);
ylim([3298000 3311000]);
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(Fault5,'FaceAlpha',1);
set(gca,'DataAspectRatio',[1.4 2 2])
view([4 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('(e)');
load InitialEnvelopeandSampleBound
subfigure6 = subplot( 2, 3, 6 );
set( subfigure6, 'Position', [0.6138, 0.0619, 0.117, 0.552]);
plot( jiaoxianCenterfun + jiaoxianRadiusfun, jiaoxianX( :, 1 ), 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);
hold on
plot( Initialupperenvelope, jiaoxianX( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
hold on
plot( jiaoxianFault(1, :), jiaoxianX( :, 1 ), 'Color', [0.9333 0.77255 0.5686], 'linewidth', 1.5);
hold on
plot([659290.3144; 659198.6785; 659139.3373; 659017.2014], unX(wellpathindex,1), 'ro','MarkerSize',4,'markerfacecolor','r' )
hold on
plot( sampleY(wellpickindex), sampleX(wellpickindex,1), 'ko','MarkerSize',4,'markerfacecolor','k' )
hold on
for i = 1 : size( givenquantile, 2 )
    plot( jiaoxianFault(i, :), jiaoxianX( :, 1 ), 'Color', [0.9333 0.77255 0.5686], 'linewidth', 1.5);
    hold on
end
plot( jiaoxianCenterfun - jiaoxianRadiusfun, jiaoxianX( :, 1 ), 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);
hold on
plot( Initiallowerenvelope, jiaoxianX( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
hold on
plot([659290.3144; 659198.6785; 659139.3373; 659017.2014], unX(wellpathindex,1), 'ro','MarkerSize',4,'markerfacecolor','r' )
hold on
plot( sampleY(wellpickindex), sampleX(wellpickindex,1), 'ko','MarkerSize',4,'markerfacecolor','k' )
set(gca,'linewidth',1.5);
set(gca,'xtick',[6.58*10^5,6.585*10^5,6.59*10^5,6.595*10^5,6.6*10^5,6.605*10^5],'ytick',[3.298*10^6,3.302*10^6,3.306*10^6,3.31*10^6]);
axis([min(jiaoxianCenterfun - jiaoxianRadiusfun)-50,max(jiaoxianCenterfun + jiaoxianRadiusfun)+50,min(jiaoxianX( :, 1 ))-200, max(jiaoxianX( :, 1 ))+200]);
set(gca,'DataAspectRatio',[1 3.5 2])
xlabel('(f)');
set(gcf,'outerposition',get(0,'screensize'));