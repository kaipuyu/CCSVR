function [beta1, beta2, beta3, beta4, beta5, bias1, bias2] = svirnwithBoundConsandFixBias1(sampleX, wellpathX, Y1, Y2, samplelb, sampleub, wellpathlb, wellpathub, gama, k3, ker, C, Q, segema)
% k3 = svkernel( ker, sampleX, sampleX, segema );
% gama - The variable nonnegative tolerance of the radius function
if ( nargin < 10 | nargin > 14) % check correct number of arguments
    help svirn
else
    fprintf (' Support Vector Interval Regressing ....\ n')
    fprintf (' ______________________________ \n')
    if ( nargin <14)
        if strcmp( ker, 'linear')
            segema = 2;
        else
            segema = 0.5 * sqrt ( sum ( (max( sampleX ) - min( sampleX )) .* (max( sampleX ) - min( sampleX )) ) );
        end
    end
    if ( nargin <13) 
        Q = ones( 1, length( sampleX ) );
    end
    if ( nargin <12) 
        C= 10000;
    end
    if ( nargin <11) 
        ker ='rbf' ;
    end
    % Construct the Kernel matrix
    fprintf (' Constructing ...\ n');
    bias1 = mean( 0.5 * ( Y1 + Y2 ) );
    bias2 = mean( 0.5 * ( Y1 - Y2 ) );
%     X = [ sampleX; wellpathX ];
    n = size ( sampleX ,1 );
    m = size ( wellpathX ,1 );
%     H3 = svkernel( ker, X, X, segema );
%     H2 = H3( 1:n, : );
%     H1 = H3( 1:n, 1:n );
    H1 = k3;
    H2 = [k3, svkernel( ker, sampleX, wellpathX, segema )];
    H3 = [H2 ; svkernel( ker, wellpathX, sampleX, segema ) , svkernel( ker, wellpathX, wellpathX, segema )];
    % Set up the parameters for the Optimisation problem
    Hb = [ 2*H1 zeros(n,n) zeros(n,n+m) -2*H2 H2; zeros(n,n) 2*H1 -2*H2 zeros(n,n+m) H2; zeros(n+m,n) -2*H2' 2*H3 zeros(n+m,n+m) -H3; -2*H2' zeros(n+m,2*n+m) 2*H3 -H3; H2' H2' -H3' -H3' H3];
    lb = [ samplelb; wellpathlb ];
    ub = [ sampleub; wellpathub ];
    %f = [( (bias1+bias2)*ones(n,1) - Y1 ); ( (-bias1+bias2)*ones(n,1) + Y2 ); (bias1-bias2)*ones(n+m,1)-lb; (-bias1-bias2)*ones(n+m,1)+ub; (bias2-1e-7)*ones(n+m,1)];
    f = [( (bias1+bias2)*ones(n,1) - Y1 ); ( (-bias1+bias2)*ones(n,1) + Y2 ); (bias1-bias2)*ones(n+m,1)-lb; (-bias1-bias2)*ones(n+m,1)+ub; (bias2-gama)*ones(n+m,1)];
    vlb = zeros ( 5 * n + 3 * m, 1 ); % Set the bounds : alphas >= 0 
    vub = [ C * Q; C * Q; inf * ones( 3*(n + m), 1 ) ]; 
    %Aeq = [ -ones( 1, n ) ones( 1, n ) -ones( 1, n + m ) ones( 1, n + m ); -ones( 1, 2 * n ) -ones( 1, 2 * ( n + m ) ) ];
    %beq = [ 0 ; 0 ]; % Set the constraint Aeqx = beq
    x0 = bias1 * ones( 5 * n + 3 * m ,1 ); 
    % Add small amount of zero order regularisation to
    % avoid problems when Hessian is badly conditioned .
    % Rank is always less than or equal to n.
    % Note that adding to much reg will peturb solution
    Hb = Hb+1e-10* eye ( size (Hb ));
    % Solve the Optimisation Problem
    %fprintf (' Optimising ...\ n');
    %[alpha lambda exitflag] = quadprog(Hb,f,[],[],Aeq,beq,vlb,vub,x0);
    [alpha lambda exitflag] = quadprog(Hb,f,[],[],[],[],vlb,vub,x0);
%     fprintf (' Status : % s\n', exitflag );
    beta1 = alpha( 1: n ) - alpha( n + 1: 2 * n );
    beta2 = alpha( 2 * n + 1 : 3 * n + m ) - alpha( 3 * n + m + 1: 4 * n + 2 * m );
    beta3 = alpha( 1: n ) + alpha( n + 1: 2 * n );
    beta4 = alpha( 2 * n + 1 : 3 * n + m ) + alpha( 3 * n + m + 1: 4 * n + 2 * m );
    beta5 = alpha( 4 * n + 2 * m + 1: 5 * n + 3 * m );
%     fprintf ('|w|^2 : % f\n', beta1' * H1 * beta1 + 2 * beta1' * H2 * beta2 + beta2' * H3 * beta2 );
%     fprintf ('|u|^2 : % f\n', beta3' * H1 * beta3 - 2 * beta3' * H2 * beta4 + beta4' * H3 * beta4 + 2 * beta3' * H2 * beta5 - 2 * beta4' * H3 * beta5 + beta5' * H3 * beta5);
    
    % Compute the number of Support Vectors
    epsilon1 = svtol ( abs ( beta1 ));
    epsilon2 = svtol ( abs ( beta2 ));
    epsilon5 = svtol ( abs ( beta5 ));
    svi1 = find ( abs ( beta1 ) >epsilon1 );
    svi2 = find ( abs ( beta2 ) >epsilon2 );
    svi3 = find ( abs ( beta5 ) >epsilon5 );
    svi4 = union( svi1, svi2);
    svi = union( svi3, svi4);
    nsv = length ( svi );
%     fprintf (' Support Vectors: % d (%3.1 f %%)\ n', nsv ,100* nsv /n); 
    % find bias from average of support vectors with interpolation error e
    % SVs with interpolation error e have alphas : 0 < alpha < C
    alpha1=alpha( 1 : n );
    alpha2=alpha( n + 1 : 2 * n );
    svii = find ( alpha1 > epsilon1 & alpha2 < ( C * Q - epsilon1 ) );
end