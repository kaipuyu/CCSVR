function SaveFigure(path, name)
% useage: SaveFigure('C:\Users\Administrator\Desktop\paper imgs', '1')
%����C:\Users\Administrator\Desktop\paper imgs��ʾ·����1��ʾ������ļ���
%     try
        mkdir(sprintf('%s/figure', path));
        mkdir(sprintf('%s/jpg', path));
        mkdir(sprintf('%s/emf', path));
        mkdir(sprintf('%s/eps', path));
%     catch
%     end
    
%     img=getimage(gcf);
    set(gcf, 'paperPositionMode', 'auto');
%     set(gcf, 'paperUnits', 'points');
%     set(gcf, 'paperposition', get(gcf, 'position'));

    fileName = sprintf('%s/figure/%s.fig', path, name);
    saveas(gcf, fileName, 'fig');
    
    fileName = sprintf('%s/jpg/%s.jpg', path, name);
%     imwrite(img, fileName, 'jpg', 'Resolution', 600);
    print('-djpeg', '-r300', fileName);
    
%     fileName = sprintf('%s/%s.tif', path, name);
% %     imwrite(img, fileName, 'tiff', 'Resolution', 600);
%     print('-dtiff', '-r300', fileName);
    
    fileName = sprintf('%s/emf/%s.emf', path, name);
    print('-dmeta', fileName);
    
    fileName = sprintf('%s/eps/%s.eps', path, name);
    print('-depsc', fileName);
end