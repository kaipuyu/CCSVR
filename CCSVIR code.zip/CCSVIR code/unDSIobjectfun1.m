function [H,f] = unDSIobjectfun1(unz,neighb1,neighb2,flag1,flag2,newZ,miu,omg)
n=length(unz);
m=length(newZ);
A=sparse(n+m,n+m);
f=sparse(n+m,1);
for i=1:n
    v1=ones(1,flag1(i,1));
    for j=1:flag1(i,1)
        l1=neighb1(i,j);
        v2=ones(1,flag2(l1,1));
        v3=ones(1,flag2(l1,2));
        A(i,i)=A(i,i)+miu(n+l1)*v1(j)^2;
        for k=1:flag2(l1,1)
            l2=neighb2(l1,k);
            if l2~=i
                A(i,l2)=A(i,l2)+miu(n+l1)*v1(j)*v2(k);
            end
        end
        for k=flag2(l1,1)+1:flag2(l1,1)+flag2(l1,2)%k��ʾ��j����ֵ�������ڵĲ�ֵ��
            l3=neighb2(l1,k);
            if l3==l1
                v3(k-flag2(l1,1))=-(flag2(l3,1)+flag2(l3,2)-1);
            end
            A(i,n+l3)=A(i,n+l3)+miu(n+l1)*v1(j)*v3(k-flag2(l1,1));
            A(n+l3,i)=A(i,n+l3);
        end
    end          
    v1=ones(1,flag1(i,2));
    for j=flag1(i,1)+1:flag1(i,1)+flag1(i,2)
        l1=neighb1(i,j);
        v2=ones(1,flag1(l1,2));
        v3=ones(1,flag1(l1,1));
        if l1==i
            v1(j-flag1(i,1))=-(flag1(l1,1)+flag1(l1,2)-1);
        end
        A(i,i)=A(i,i)+miu(l1)*v1(j-flag1(i,1))^2;
        for k=flag1(l1,1)+1:flag1(l1,1)+flag1(l1,2)
            l2=neighb1(l1,k);
            if l2==l1
                v2(k-flag1(l1,1))=-(flag1(l2,1)+flag1(l2,2)-1);
            end
            if l2~=i
                A(i,l2)=A(i,l2)+miu(l1)*v1(j-flag1(i,1))*v2(k-flag1(l1,1));
            end
        end
        for k=1:flag1(l1,1)
            l3=neighb1(l1,k);
            A(i,n+l3)=A(i,n+l3)+miu(l1)*v1(j-flag1(i,1))*v3(k);
            A(n+l3,i)=A(i,n+l3);
        end
    end
end
for i=1:m
    v1=ones(1,flag2(i,1));
    f(n+i,1)=-2*omg(i)*newZ(i);
    A(n+i,n+i)=omg(i)+A(n+i,n+i);
    for j=1:flag2(i,1)
        l1=neighb2(i,j);
        v2=ones(1,flag1(l1,1));
        v3=ones(1,flag1(l1,2));
        A(n+i,n+i)=A(n+i,n+i)+miu(l1)*v1(j)^2;
        for k=1:flag1(l1,1)
            l2=neighb1(l1,k);
            if l2~=i
                A(n+i,n+l2)=A(n+i,n+l2)+miu(l1)*v1(j)*v2(k);
            end
        end
    end       
    v1=ones(1,flag2(i,2));
    for j=flag2(i,1)+1:flag2(i,1)+flag2(i,2)
        l1=neighb2(i,j);
        v2=ones(1,flag2(l1,2));
        v3=ones(1,flag2(l1,1));
        if l1==i
            v1(j-flag2(i,1))=-(flag2(l1,1)+flag2(l1,2)-1);
        end
        A(n+i,n+i)=A(n+i,n+i)+miu(n+l1)*v1(j-flag2(i,1))^2; 
        for k=flag2(l1,1)+1:flag2(l1,1)+flag2(l1,2)
            l2=neighb2(l1,k);
            if l2==l1
                v2(k-flag2(l1,1))=-(flag2(l2,1)+flag2(l2,2)-1);
            end
            if l2~=i
                A(n+i,n+l2)=A(n+i,n+l2)+miu(n+l1)*v1(j-flag2(i,1))*v2(k-flag2(l1,1));
            end
        end
    end
end    
H=2.*A;