function [neighb1,neighb2,flag1,flag2] = neighbh(unx, uny, newX, newY, r, k)
n=length(unx);
m=length(newX);
neighb1=zeros(n,k);
neighb2=zeros(m,k);
flag1=zeros(n,2);
flag2=zeros(m,2);
for i=1:n
    for j=1:m
        if sqrt((unx(i)-newX(j))^2+(uny(i)-newY(j))^2)<=r
            neighb1(i,flag1(i,1)+1)=j;
            neighb2(j,flag2(j,1)+1)=i;
            flag1(i,1)=flag1(i,1)+1;
            flag2(j,1)=flag2(j,1)+1;
        end
    end
end
for i=1:n
    fl1(i)=flag1(i,1);
    for j=1:n
        if sqrt((unx(i)-unx(j))^2+(uny(i)-uny(j))^2)<=r
            neighb1(i,fl1(i)+1)=j;
            fl1(i)=fl1(i)+1;
        end
    end
    flag1(i,2)=fl1(i)-flag1(i,1);
end
for j=1:m
    fl2(j)=flag2(j,1);
    for i=1:m
        if sqrt((newX(i)-newX(j))^2+(newY(i)-newY(j))^2)<=r
            neighb2(j,fl2(j)+1)=i;
            fl2(j)=fl2(j)+1;
        end
    end
    flag2(j,2)=fl2(j)-flag2(j,1);
end           