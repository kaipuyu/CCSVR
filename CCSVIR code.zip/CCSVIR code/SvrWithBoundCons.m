function [beta1, beta2, bias] = SvrWithBoundCons(sampleX, wellpathX, sampleY, samplelb, sampleub, wellpathlb, wellpathub, epsl, ker, C, Q, segema)
% SVIRN Support vector interval regression network.
%
% Usage : [beta1, beta2, bias] = SvrWithBoundCons(sampleX, wellpathX, sampleY, samplelb, sampleub, wellpathlb, wellpathub, epsl, ker, C, Q, segema)
if ( nargin < 8 | nargin > 12) % check correct number of arguments
    help svirn
else
    fprintf (' Support Vector Interval Regressing ....\ n')
    fprintf (' ______________________________ \n')
    if ( nargin <12)
        if strcmp( ker, 'linear')
            segema = 2;
        else
            segema = 0.5 * sqrt ( sum ( (max( sampleX ) - min( sampleX )) .* (max( sampleX ) - min( sampleX )) ) );
        end
    end
    if ( nargin <11) 
        Q = ones( 1, length( sampleX ) );
    end
    if ( nargin <10) 
        C= 100;
    end
    if ( nargin <9) 
        ker ='rbf' ;
    end
    % Construct the Kernel matrix
    fprintf (' Constructing ...\ n');
    %bias = mean(sampleY);
    X = [ sampleX; wellpathX ];
    n = size ( sampleX ,1 );
    m = size ( wellpathX ,1 );
    H3 = svkernel( ker, X, X, segema );
    H2 = H3( 1:n, : );
    H1 = H3( 1:n, 1:n );
    % Set up the parameters for the Optimisation problem
    %Hb = [ H1 -H1 2*H2 -2*H2; -H1 H1 -2*H2 2*H2; zeros(n+m,2*n) H3 -H3; zeros(n+m,2*n) -H3 H3];
    Hb = [ H1 -H1 H2 -H2; -H1 H1 -H2 H2; H2' -H2' H3 -H3; -H2' H2' -H3 H3];
    lb = [ samplelb; wellpathlb ];
    ub = [ sampleub; wellpathub ];
    f = [( - sampleY + epsl * ones( n, 1 ) ); ( sampleY + epsl * ones( n, 1 ) ); -lb; ub];
    vlb = zeros ( 4 * n + 2 * m, 1 ); % Set the bounds
    vub = [ C * Q; C * Q; inf * ones( 2*(n + m), 1 ) ]; 
    Aeq = [ -ones( 1, n ) ones( 1, n ) -ones( 1, n + m ) ones( 1, n + m ) ];
    beq = 0; % Set the constraint Aeqx = beq
    x0 = mean( sampleY ) * ones( 4 * n + 2 * m ,1 ); 
    % Add small amount of zero order regularisation to
    % avoid problems when Hessian is badly conditioned .
    % Rank is always less than or equal to n.
    % Note that adding to much reg will peturb solution
    Hb = Hb+1e-10* eye ( size (Hb ));
    % Solve the Optimisation Problem
    %fprintf (' Optimising ...\ n');
    st = cputime;
    [alpha lambda exitflag] = quadprog(Hb,f,[],[],Aeq,beq,vlb,vub,x0);
    %fprintf (' Execution time : %4.1 f seconds \n', cputime - st );
    %fprintf (' Status : % s\n', exitflag );
    beta1 = alpha( 1: n ) - alpha( n + 1: 2 * n );
    beta2 = alpha( 2 * n + 1 : 3 * n + m ) - alpha( 3 * n + m + 1: 4 * n + 2 * m );
    %fprintf ('|w|^2 : % f\n', beta1' * H1 * beta1 + 2 * beta1' * H2 * beta2 + beta2' * H3 * beta2 );
    
    % Compute the number of Support Vectors
    epsilon = svtol ( abs ( beta1 ));
    svi = find ( abs ( beta1 ) >epsilon );
    nsv = length ( svi );
    %fprintf (' Support Vectors: % d (%3.1 f %%)\ n', nsv ,100* nsv /n); 
    % find bias from average of support vectors with interpolation error e
    % SVs with interpolation error e have alphas : 0 < alpha < C
    alpha1=alpha( 1 : n );
    alpha2=alpha( n + 1 : 2 * n );
    svii = find ( abs ( beta1 ) > epsilon & abs ( beta1 ) < ( C * Q - epsilon ));
    if ~isempty ( svii )
        bias = (1/ length ( svii )) * sum ( sampleY( svii ) - epsl* sign ( beta1 ( svii )) - H1( svii , svi ) * beta1 ( svi ) - H2( svii , : ) * beta2 );
    else
        fprintf ('No support vectors - cannot compute bias .\n');
    end
end