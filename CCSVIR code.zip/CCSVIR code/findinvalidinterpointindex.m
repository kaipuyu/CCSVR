function [invalidpointyindex,invalidpointzindex]=findinvalidinterpointindex(y, z, strikeindex, yinternum, zinternum)
%�ú������ҵ���Ч������
sticknum = max( strikeindex );
yminv = min( y );
ymaxv = max( y );
zminv = min( z );
zmaxv = max( z );
firststrikeindex = find( strikeindex == 1 );
laststrikeindex = find( strikeindex == sticknum );
yfirststrike = y( firststrikeindex );
zfirststrike = z( firststrikeindex );
ylaststrike = y( laststrikeindex );
zlaststrike = z( laststrikeindex );
ylaststrike(length(ylaststrike)+1) = ymaxv;
zlaststrike(length(ylaststrike)) = zminv;
yinterval = ( ymaxv - yminv ) / ( yinternum - 1 );
zinterval = ( zmaxv - zminv ) / ( zinternum - 1 );
zleft = zminv: zinterval: zmaxv;
zright = zminv: zinterval: zmaxv;
yleft=interp1(zfirststrike, yfirststrike, zleft, 'PCHIP');
yright=interp1(zlaststrike, ylaststrike,  zright, 'PCHIP');
interpointnum = 0;
for i=1: floor( ( max(yleft)-yminv ) / yinterval ) + 1
    for j=1: zinternum
        currentpointy = yminv + ( i - 1 ) * yinterval;
        if  currentpointy < yleft( j )
            interpointnum = interpointnum + 1;
            invalidpointyindex( interpointnum ) = i;
            invalidpointzindex( interpointnum ) = j;
        end
    end
end
for i=floor( ( min(yright) - yminv ) / yinterval ) + 2 : floor( ( ymaxv - yminv ) / yinterval ) + 1
    for j=1: zinternum
        currentpointy = yminv + ( i - 1 ) * yinterval;
        if  currentpointy > yright( j )
            interpointnum = interpointnum + 1;
            invalidpointyindex( interpointnum ) = i;
            invalidpointzindex( interpointnum ) = j;
        end
    end
end